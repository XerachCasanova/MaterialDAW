/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog02_ejerc1;

import java.util.Scanner;

/**
 *
 * @author Xerach
 */
public class PROG02_Ejerc4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*genero una variable booleana para guardar el valor que analizaremos
        después sobre la mayoría de edad del suuario
        */
        boolean mayorEdad = false;
        
        /*Pido al usuario que introduzca su edad, para ello, declaramos
        una variable de tipo byte, que es suficiente para la edad de un usuario.
        En la misma línea inicializamos la variable con la instrucción
        Scanner(System.in).nextByte(); la cual hace que se pida introducir un
        dato en la consola. Inicializando en la misma línea ahorramos tener que
        crear una variable referencia de tipo Scanner.
        */
        System.out.print("Introduce tu edad: ");
        byte edad = new Scanner(System.in).nextByte();
        
        
        /*Analizo la variable edad con el operador condicional (?:), sí
        se cumple la instrucción, guardaremos en la variable booleana el valor
        true y si no, guardaremos false.
        */
        mayorEdad = (edad >= 18);
      
        /*Genero otra variable referencia de tipo String y analizo la variable
        booleana con otro operador condicional. Esta variable servirá para
        seguidamente imprimir por pantalla el resultado de una manera legible
        para el usuario.*/
        
        /*Nota: realmente, al solo haber dos resultados posibles tratándose de una
        variable booleana.
        */
        String respuestaMayorEdad = (mayorEdad) ? "SÍ" : "NO";
        
        System.out.printf("El usuario %s es mayor de edad.", respuestaMayorEdad);
      
        
    }
    
}
