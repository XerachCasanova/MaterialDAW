/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog02_ejerc1;

/**
 *
 * @author Xerach
 */
public class PROG02_Ejerc1 {

    /**
     * @param args the command line arguments
     */
    
    
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        /* es una constante, por lo tanto su valor no variará durante la ejecución
        del programa. El valor 5000 de la constante permite declararla como tipo
        short, ya que entra en el rango para este tipo de dato.
        */
        final short const5000 = 5000;
        
        /*
        Declaramos una variable de tipo booleano para más adelante asignarle valor
        true si el nuevo empleado tiene carnet de conducir. En caso de que no lo
        tenga el valor será false.
        */
        boolean permisoConducir = false;
        
        /*
        En el caso de mesNumerico es una variable de tipo byte, para almacenar un
        mes del año cualquiera en formato numérico. El valor de los meses variará
        entre 1 y 12, así que entra en el rango de tipo byte.

        En el caso de mesCadena, es un objeto de tipo String, al cual le asignamos
        el nombre del mes.
        */
        byte mesNumerico = 2;
        String mesCadena = "febrero";
        
        /*
        Inicializamos un string con mi nombre. No se trata de un tipo primitivo, sino
        de un tipo referenciado.
        */
        String nombreApellidos = "Xerach E. Casanova Cabrera";
        
        /*
        Declaramos la variable sexo de tipo char, ya que puede almacenar un carácter
        único y nos servirá para almacenar 'V' o 'M.
        */
        char sexo ='V';
        
        /*
        Declaramos la variable de tipo entero long milisegundos. Le asignamos el
        valor de los milisegundos aproximados transcurridos desde el 01/01/1970
        hasta nuestros días. Al ser un tipo long, debemos poner la constante literal
        L detrás del número para indicar que se trata de un long en vez de un int.
        */
        long milisegundos = 1607300370000L;
        
        /*
        Declaramos una variable de tipo float llamada saldo. Una variable con un
        rango lo suficientemente grande como para almacenar grandes cantidades de
        dinero y además incluyendo decimales. Al final del valor a declarar
        se debe utilizar la constante literal F para indicar que se trata de un
        float y no de un double.
        */
        float saldo = 168458954534388455224.25F;
        
        /*
        La distancia entre la Tierra y Júpiter puede ser expresada en una variable
        de tipo int, ya que dicha cifra no sobrepasa su rango.
        */
        int distTierraJupiter = 660000000;
        
        /*
        Para imprimir por la consola de java el valor de las variables anteriormente
        declaradas utilizo el método print, el cual no inserta saltos de línea,
        pero lo hago manualmente añadiendo un retorno de carro \n concatenado 
        a la variable.
        */
        System.out.print(const5000+"\n");
        System.out.print(permisoConducir +"\n");
        System.out.print(mesNumerico +"\n");
        System.out.print(mesCadena +"\n");
        System.out.print(nombreApellidos +"\n");
        System.out.print(sexo +"\n");
        System.out.print(milisegundos +"\n");
        System.out.print(saldo +"\n");
        System.out.print(distTierraJupiter +"\n");
  
        
    }
    
}
