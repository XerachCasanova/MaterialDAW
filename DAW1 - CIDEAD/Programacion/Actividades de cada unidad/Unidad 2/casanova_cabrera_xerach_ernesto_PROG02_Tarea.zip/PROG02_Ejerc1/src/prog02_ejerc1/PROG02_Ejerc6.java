/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog02_ejerc1;

/**
 *
 * @author Xerach
 */
public class PROG02_Ejerc6 {

    /**
     * @param args the command line arguments
     */
    
    /*
    Genero la variable tipo enumerado razas, en la cual insertamos los valores
    de las distintas razas.
    */
    enum razas {Mastín, Terrier, Bulldog, Pekines, Caniche, Galgo};
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        Construyo dos variables de tipo referenciado razas y guardo en ellas
        el valor de una raza en concreto definida anteriormente en la variable
        razas
        */
        
        razas var1 = razas.Terrier;
        razas var2 = razas.Pekines;
        
        /*
        Muestro por pantalla los valores de ambas variables
        */
        
        System.out.println("la raza nº 1 es " + var1);
        System.out.println("la raza nº 2 es " + var2);
        
        
        /*
        El método values().length devuelve el número de valores que tiene
        la variable enum. Muestro por pantalla este valor.
        */
        System.out.print("El tamaño del tipo enumerado es de ");
        System.out.println(razas.values().length+ " valores");
        
        
        /*
        Con el método ordinal() podemos averiguar la posición que ocupa un 
        determinado elemento en la variable enum. El valor que devuelve es su
        posición real dentro del enum, teniendo en cuenta que la posición del
        primer valor es 0, así que para mostrar dicho valor le sumo 1.
        */
        
        System.out.print("La posición que ocupa el valor de var 1 en el enumerado es: ");
        System.out.println(var1.ordinal()+1);
        System.out.print("La posición que ocupa el valor de var 2 en el enumerado es: ");
        System.out.println(var2.ordinal()+1);

        
    }
    
}
