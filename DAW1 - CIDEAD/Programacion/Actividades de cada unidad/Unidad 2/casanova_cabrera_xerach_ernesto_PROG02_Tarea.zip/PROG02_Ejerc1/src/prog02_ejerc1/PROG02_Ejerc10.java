/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog02_ejerc1;

/**
 *
 * @author Xerach
 */
public class PROG02_Ejerc10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("------Conversiones entre enteros y coma flotante------");
        
        float x = 4.5f;
        float y = 3.0f;
        int i = 2;
        
        int j = (int)(i*x);
        
        System.out.println("Producto de int x float: j = i*x = " + j);
        
        double dx = 2.0;
        double dz = dx * y;
        
        System.out.println("Producto de double x float: dz = dx*y = " + dz);
        
        System.out.println("------Operaciones con byte------");
        
        byte bx = 5;
        byte by = 2;
        byte bz = (byte)(bx - by);
        
        System.out.println("byte: 5 - 2 = " + bz);
        
        bx = -128;
        by = 1;
        bz = (byte)(bx - by);
        
        System.out.println("byte: -128 - 1 = " + bz);
       
        int enteroByte = (int) (bx - by);
        
        System.out.println("int: -128 - 1 = " + enteroByte);
        
        System.out.println("------Operaciones con short------");
        
        short sx = 5;
        short sy = 2;
        short sz = (short) (sx - sy);
        
        System.out.println("short: 5 - 2 = " + sz);
        
        sx = 32767;
        sy = 1;
        sz = (short) (sx + sy);
        
        System.out.println("short: 32767 + 1 = " + sz);
        
        System.out.println("------Operaciones con char------");
        
        char cx = '\u000F';
        char cy = '\u0001';
        int z = cx - cy;
        
        System.out.println("char - = " + z);
        
        z = cx - 1;
        
        System.out.println("char (0x000F) -1 = " + z);
        
        cx = '\uFFFF';
        z = cx;
        
        System.out.println("int ( ) = " + z);
        
        sx = (short)cx;
        
        System.out.println("short( ) = " + sx);
        
        sx = -32768;
        
        System.out.println("-32768 short-char-int = " + sx);
        
        cx = (char)sx;
        z = sx;
        sx = -1;
        cx = (char)sx;
        z = cx;
        
        System.out.println("-1 short-char-int = " + z);
       
    }
    
}
