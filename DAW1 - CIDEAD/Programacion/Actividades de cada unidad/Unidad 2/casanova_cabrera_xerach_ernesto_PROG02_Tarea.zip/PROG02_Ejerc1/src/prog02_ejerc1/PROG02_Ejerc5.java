/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog02_ejerc1;

import java.util.Scanner;

/**
 *
 * @author Xerach
 */
public class PROG02_Ejerc5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        declaro las variables que voy a utilizar para guardar los valores
        de los minutos, horas y días que equivalen a los segundos que introducirá
        el usuario. El tipo de dato en el que declaro las variables es float,
        ya que al realizar las divisiones, es probable que el valor en el que
        se inicializarán las variables sera real.
        */
        double minutos, horas, dias;
        
        /*
        Declaro otras variables de tipo entero, para que a la hora de mostrar
        por la consola los resultados, lo haga con valores enteros y no con decimales
        */
        int nSegundos, nMinutos, nHoras, nDias;
        
        
        /*
        Pido al usuario que introduzca el número de segundos por consola.
        */
        System.out.print("Introduce un número de segundos: ");
        double segundos = new Scanner(System.in).nextLong();
        
        /*
        Inicializo las variables que contienen los valores reales de los días
        horas y minutos que son los segundos introducidos. Se puede realizar
        esta instrucción en una sola línea o en varias. Quizás, haciéndolo en
        varias el código será más legible:
        minutos = (double)segundos/60;
        horas = minutos/60;
        dias = horas/24;
        */
        
        dias = (horas = (minutos = (segundos)/60)/60)/24;
       
        /*
        Realizo el cálculo de cuantos días, horas, minutos y segundos son
        los segundos introducidos, para ello hago el cálculo del resto resultante
        entre los segundos introducidos y 60 para los segundos y minutos
        (1 minuto tiene 60 segundos y una hora tiene 60 minutos) y entre 24
        para las horas (1 día tiene 24 horas). La variable días se queda tal
        cual está. Todo ello se realiza haciendo una conversión de tipos normal,
        haciendo que el valor de las variables tipo float se trunquen, guardando
        en las variables de tipo int solo la parte entera.
        */
        nSegundos = (int)segundos%60;
        nMinutos = (int) minutos%60;
        nHoras = (int)(horas%24);
        nDias = (int)dias;

        /*Por último, imprimo en pantalla el resultado*/
        System.out.printf("El número de segundos introducidos equivalen a %d días, %d horas, %d minutos y %d segundos",nDias, nHoras, nMinutos, nSegundos);
    }
    
}
