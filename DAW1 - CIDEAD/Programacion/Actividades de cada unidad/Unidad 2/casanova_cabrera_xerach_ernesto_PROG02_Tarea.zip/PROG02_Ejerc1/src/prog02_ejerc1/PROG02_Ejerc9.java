/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog02_ejerc1;

import java.util.Scanner;

/**
 *
 * @author Xerach
 */
public class PROG02_Ejerc9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //declaro una variable booleana y la inicializo en false
        boolean bisiesto = false;
        
        /*pido al usuario que introduzca el año a comprobar, el tipo de dato
        a utilizar es short, ya que para expresar años puede ser un rango adecuado*/
        
        System.out.print("Introduce un año para comprobar si es bisiesto: ");
        short anio = new Scanner(System.in).nextShort();
        
        /*En las operaciones lógicas siguientes, primero se compara si el año es
        divisible entre 4 y después si no es divisible entre 100, si ambas condiciones
        se cumplen entonces será true. Seguidamente se compara si año es divisible
        entre 400, en ese caso, aunque la comparación anterior fuera false, el resultado
        final será verdadero.*/
        
        /*Nota: realmente, estoy utilizando el operador ternario "?", pero en el
        caso de condiciones sobre variables booleanas no hace falta poner la instrucción
        de asignación de valores.*/
        bisiesto = ((anio%4 == 0) && (anio%100 !=0) || anio%400==0); //? true : false;
        
        
        /*Declaro una variable de tipo referenciado String y la inicializo dándole valor
        de Sí o No, dependiendo del contenido de la variable booleana bisiesto
        */
        String respuestaBisiesto = bisiesto ? "SÍ" : "NO";
        
        //imprimo por pantalla el resultado del año y si es bisiesto o no.
        System.out.printf("\nEl año %d %s es bisiesto\n", anio, respuestaBisiesto);
       

    }
    
}
