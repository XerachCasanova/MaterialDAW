/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog02_ejerc1;

import java.util.Scanner;

/**
 *
 * @author Xerach
 */
public class PROG02_Ejerc7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        Declaro las variables C1, C2 y x para asignarles valor más adelante
        */
        double C1, C2, x;
        
        /*Le pido al usuario que introduzca los valores de C1 y C2, a través
        de la clase Scanner, e inicializo ambas variables con el resultado
        */
        System.out.print("Introduce el valor de C1: ");
        C1 = new Scanner(System.in).nextDouble();
        
        System.out.print("\nIntroduce el valor de C2: ");
        C2 = new Scanner(System.in).nextDouble();
        
        //inicializo x realizando la ecuación siguiente para resolverla
        
        x = -C2/C1;
        
        
        //Muestro por pantalla el valor de x dándole formato de 4 dígitos
        System.out.printf("\nEl valor de X es : %.4f\n",  x);
        
    }
    
}
