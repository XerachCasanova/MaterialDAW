/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog02_ejerc1;

import java.util.Scanner;

/**
 *
 * @author Xerach
 */
public class PROG02_Ejerc8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
        
        int alumnosProg, alumnosBD, alumnosED, totalAlumnos;
        
        System.out.print("Introduce el nº de alumnos matriculados en Programación: ");
        alumnosProg = new Scanner(System.in).nextInt();
        
        System.out.print("Introduce el nº de alumnos matriculados en Bases de Datos: ");
        alumnosBD = new Scanner(System.in).nextInt();
        
        System.out.print("Introduce el nº de alumnos matriculados en Entornos de Desarrollo: ");
        alumnosED = new Scanner(System.in).nextInt();
        
        totalAlumnos = alumnosProg + alumnosBD + alumnosED;
        
        System.out.printf("Hay un %.1f%% de alumnos matriculados en Programación", (float)alumnosProg*100/totalAlumnos);
        
        System.out.printf("\nHay un %.1f%% de alumnos matriculados en Bases de Datos", (float)alumnosBD*100/totalAlumnos);
        
        System.out.printf("\nHay un %.1f%% de alumnos matriculados en Entornos de Desarrollo\n", (float)alumnosED*100/totalAlumnos);
    
        
    }
    
        
    
}
