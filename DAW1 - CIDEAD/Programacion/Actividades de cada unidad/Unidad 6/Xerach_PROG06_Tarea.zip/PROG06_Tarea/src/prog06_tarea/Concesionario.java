/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog06_tarea;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import prog06_Ejerc1_util.ValidarDatos;

/**
 *
 * @author Xerach E. Casanova Cabrera - DAW A
 * 
 */

public class Concesionario {
    
    private static int nTotalVehiculos = 0;
    
    private Vehiculo[] vehiculos = new Vehiculo[50];
    
    /**
     * Constructor de la clase concesionario.
     * 
     */    
    public Concesionario(){
        
            
  
        
    } //fin Concesionario()
    
   /**
    * Busca un vehículo a partir de la matrícula que se pasa por parámetro.
    * 
    * @param matricula a comprobar
    * @return 
    */ 
   public String buscaVehiculo(String matricula){
        
        /* Creamos una variable String nula y recorremos el array de tipo 
       vehículo para buscar coincidencias con la matrícula.*/
       
        String vehiculo = null;
        
        for (int i=0; i<nTotalVehiculos; i++){
            
            if (matricula.equals(vehiculos[i].getMatricula())){ //si encuentra la matrícula
                
                vehiculo =""; //le asignamos un valor inicial vacío al vehículo.
                
                for (int j=0; j<imprimirVehiculo(i).length; j++){
                    
                    /*Se recorre el método de tipo array de Strings completo y se guarda
                    en una variable el contenido de cada String contenido en el array*/
                    vehiculo = vehiculo + imprimirVehiculo(i)[j];  
                    
                } //fin for  
                
                 break; //Si encuentra una matrícula no hace falta seguir recorriendo el array. Salimos del bucle.
                 
            } //fin if
            
        } //fin for
        
        return vehiculo; //Devuelve null si no encuentra matrícula o una cadena con los datos del vehículo si encuentra una coincidencia.
        
    } //fin buscaVehiculo()
    
    /**
    * Método encargado de crear nuevos vehículos con los atributos recibidos por
    * parámetros.
    * 
    * @param marca a insertar en el objeto tipo vehículo.
    * @param matricula a insertar en el objeto tipo vehículo.
    * @param propietario a insertar en el objeto tipo vehículo.
    * @param descripcion a insertar en el objeto tipo vehículo.
    * @param km a insertar en el objeto tipo vehículo.
    * @param dni a insertar en el objeto tipo vehículo.
    * @param precio a insertar en el objeto tipo vehículo.
    * @param fechaMatr a insertar en el objeto tipo vehículo.
    * @return 0 para indicar que el vehículo se ha creado con éxito, 
    * -1 para indicar concesionario lleno, -2 para indicar que la matrícula ya existe
    */
   
    public int insertaVehiculo(String marca, String matricula, String propietario, String descripcion, int km, String dni, float precio, LocalDate fechaMatr ){
        
        /*Creamos una variable de tipo booleana que en principio tendrá valor false,
        recorremos el array hasta el número total de vehículos que hay creados.*/
        
        boolean matriculaExiste = false;
        
        
        for (int i=0; i<nTotalVehiculos; i++){
            /*Aunque se ha implementado que al borrar un registro se reordene 
            la lista para no dejar registros nulos en medio, esta comprobación
            evitaría error si se encuentra algún nulo en medio del array:*/
            if (vehiculos[i] != null) { 
                
                //Si encuentra una matrícula
                if (matricula.equals(vehiculos[i].getMatricula())){
                    
                matriculaExiste = true; //setteamos la variable booleana en true y salimos del bucle.   
                break;
                
                } //fin if
                
            } //fin if
            
        } //fin for
        
        if (matriculaExiste) return -2; //si la matrícula existe devolvemos -2 y salimos sin insertar vehículos.
        else if (nTotalVehiculos==vehiculos.length) return -1; //si el número total de vehículos es igual al máximo del array devolvemos -1 y salimos sin insertar vehículos
        else { 
            
            /*Si la matrícula no existe, recorremos el array en busca de un espacio
            nulo en el que insertar el nuevo objeto de tipo vehículo*/
            
            for (int i=0; i<=nTotalVehiculos; i++) {
                
                if (vehiculos[i] == null) {
                    
                    vehiculos[i] = new Vehiculo(marca, matricula, propietario, descripcion, km, dni, precio, fechaMatr);
                    
                } //fin if
                
            } //fin for
            
            nTotalVehiculos++; //Sumamos 1 al número total de vehículos.
            return 0; //devolvemos 0 para indicar que el vehículo se ha creado correctamente.
            
        } //if - else
        
    } //fin insertaVehiculo()
    
    public void listaVehiculos(){
        
        /*
        Creamos un array de string del tamaño total de las cadenas contenidas
        en el método de tipo array 'imprimirVehiculo'
        */
        if (nTotalVehiculos!=0) {
            String impresion[] = new String[imprimirVehiculo(0).length];

            // Imprimimos el número total de vehículos.
            System.out.println("Número total de vehículos: " + nTotalVehiculos);
            System.out.println("-----------------------------------");

            /*Recorremos el array de tipo Vehículo hasta donde hay guardados registros*/
            for (int i=0; i<nTotalVehiculos; i++){

                /*Recorremos el método de tipo array imprimirVehiculo en busca de las distintas
                cadenas contenidas en el array de String y las imprimimos por consola.*/
                for (int j=0; j<imprimirVehiculo(i).length; j++){

                     System.out.print(imprimirVehiculo(i)[j]);

                } //fin for

            } //fin for
        } else {
            
            System.out.println("No hay vehículos creados.");
            
        } //fin if-else
        
    } //fin listaVehiculos()
    
    /**
     * Método que actualiza los kilómetros de los distintos vehículos contenidos
     * en la clase concesionario, a partir de una matrícula dada por parámetro
     * y un número de kilómetros.
     * 
     * @param matricula a buscar
     * @param kms a modificar en el vehículo.
     * 
     * @return verdadero si se han actualizado los kilómetros o falso si no se han actualizado.
     */
    public boolean actualizaKms(String matricula, int kms){
        
        /*Creamos una variable booleana que será falsa desde el inicio y será verdadera
        si se actualizan los kilómetros. */
        
        boolean kmActualizados = false;
        
        //Recorremos el array de tipo Vehiculo hasta donde hay registros guardados
        for  (int i=0; i<nTotalVehiculos ; i++) {
            // si encuentra una matrícula
            if (matricula.equals(vehiculos[i].getMatricula())) {
                
                try {
                    /*Llamamos al método validar para comprobar que los kilómetros
                    que vamos a actualizar son correctos.*/
                    
                    ValidarDatos.validarKms(kms, vehiculos[i].getKm());
                    vehiculos[i].setKm(kms); //actualizamos kilómetros
                    kmActualizados = true; // modificamos la variable booleana
                    
                } catch (Exception e) {
                    /*Si el método validar devuelve una excepción, la capturamos
                    y la imprimimos en consola.*/
                    System.out.println(e.getMessage()); 
                    
                } //fin try - catch
                  
                break; //Cuando encuentra una matrícula dejamos de recorrer el array.
            } //fin if
            
        } //fin for
        
        return kmActualizados; //devuelve true si se ha actualizado o false si no se ha actualiado.
        
    } //fin actualizaKms()
    
    
    /**
     * Método que se encarga de borrar vehículos a partir de la matrícula que
     * se indique por parámetros 
     * 
     * @param matricula del vehículo a borrar
     * @return  true si se ha borrado correctamente, false si no se ha podido borrar.
     */
    public boolean borraVehiculo(String matricula) {
        /* Creamos una variable booleana a la que le daremos valor verdadero si se
        logra borrar un registro, además creamos una variable contador para indicar
        la posición en la que se ha borrado*/
        
        int i=0;
        boolean borrado = false;
        
        /*Recorremos el array hasta el número total de registros almacenados
        en busca de un vehículo que coincida con la matrícula que se nos
        pasa por parámetro */
        for (i=0; i<nTotalVehiculos; i++) {
            
            if (matricula.equals(vehiculos[i].getMatricula())){
                
                
                vehiculos[i] = null; //Si encuentra el vehículo, borra sus datos
                nTotalVehiculos--; //resta uno a la variable que cuenta el total de vehículos.
                
                borrado = true; //igualamos la variable booleana a true
                
                break; //salimos del bucle
            }  //fin if
             
        } //fin for
        
        /*llamamos al método que se encarga de reordenar registros pasándole
        por parámetro el número de registro que se encuentra vacío ahora mismo.*/
        reordenarRegistros(i); 
        
        return borrado; //devuelve true si se borró correctamente o false si no se borró.
    } //fin borraVehiculo()
    
    /**
     * Reordena los registros a partir de un índice de comienzo en el array.
     * @param regComienzo a partir del cual se empieza a reordenar el array.
     */
    private void reordenarRegistros(int regComienzo){
        
        /* Recorremos el array a partir del registro de comienzo que le pasamos
        por parámetro hasta el número máximo de vehículos en el array y pasamos
        los datos del vehículo del registro siguiente al registro actual.*/
        for (int i = regComienzo; i < nTotalVehiculos; i++){
            
            vehiculos[i] = vehiculos[i+1];
            
        }
        
    }
    
    /**
     * Método que se encarga de generar un array de Strings que contiene
     * los datos del vehículo de la posición del array que se le pasa por parámetros
     * 
     * @param nVehiculo posición del vehículo en el array
     * @return array de Strings con los datos del vehículo.
     */
    private String[] imprimirVehiculo(int nVehiculo){

        String[] vehiculo = {
        "\n*****Coche nº" + (nVehiculo+1) + "*****",
        "\nMarca: " + vehiculos[nVehiculo].getMarca(),
        "\nMatrícula: " + vehiculos[nVehiculo].getMatricula(),
        "\nPropietario: " + vehiculos[nVehiculo].getPropietario(),
        "\nDNI: " + vehiculos[nVehiculo].getDni(),
        "\nDescripción: " + vehiculos[nVehiculo].getDescripcion(),
        "\nKilómetros: " + vehiculos[nVehiculo].getKm(),
        "\nFecha de matriculación: " + vehiculos[nVehiculo].getFechaMatr().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
        "\nPrecio: " + vehiculos[nVehiculo].getPrecio() + " €\n"
        };
        return vehiculo;
  
        
        
        
    } //fin imprimirVehiculo()
     
    
} //fin clase Concesionario
