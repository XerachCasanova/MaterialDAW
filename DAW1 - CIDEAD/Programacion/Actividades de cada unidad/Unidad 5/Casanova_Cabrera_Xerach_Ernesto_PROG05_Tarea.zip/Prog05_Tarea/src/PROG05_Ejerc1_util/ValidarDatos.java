/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROG05_Ejerc1_util;

import java.time.LocalDate;

/**
 * Esta clase se encarga de validar los datos que el usuario introduce por
 * pantalla, se recomienda manejar excepciones con el uso de los métodos de
 * esta clase.
 * 
 * @author Xerach E. Casanova Cabrera - DAW A
 */
public class ValidarDatos {
    
   
    private static final String LETRAS_DNI= "TRWAGMYFPDXBNJZSQVHLCKE";
    
    //---------------------------------------------------------------
    //MÉTODOS DE VALIDACIÓN DEL DNI
    
    /**
     * 
     * @param dni Cadena que contiene el número junto con la letra del DNI.

     * 
     * @return Devuelve la letra que le corresponde al DNI de ese número concreto.
     */
    private static char calcularLetraDNI (int dni) {

        char letra;

        letra = LETRAS_DNI.charAt(dni % 23);       

        return letra; 

    }   
    
    /**
     * Se encarga de extraer la letra del DNI que se pasa por parámetro al método,
     * el cual contiene un DNI completo, con número y letra.
     * 
     * @param dni Cadena que contiene el número junto con la letra del DNI.
     * @return variable tipo char que contiene la letra del DNI que se ha pasado
     * por parámetro.
     */
    private static char extraerLetraDNI (String dni) {

        char letra = dni.charAt(dni.length()-1);
        
        return Character.toUpperCase(letra);

    }
    
    
    
    /**
     * Se encarga de extraer el número del DNI que se pasa por parámetro al método,
     * el cual contiene un DNI completo, con número y letra.
     * 
     * @param dni Cadena que contiene el número junto con la letra del DNI.
     * @return variable de tipo entero que contiene el número del DNI que se ha
     * pasado por parámetro.
     */
    private static int extraerNumeroDNI (String dni) {
        
        int numero;
        
        /* Analizamos si el DNI introducido tiene una letra como carácter inicial
        Para tratar el dni como un NIE.
        */
        
        if (Character.isLetter(dni.charAt(0))) {
            
            char nie = dni.charAt(0);
            
            /*En caso de que sea un NIE, analizamos que letra es y asignamos
            a esa letra un 0 para la X, un 1 para la Y y un 2 para la Z.
            */
            
            switch (nie) {
                case 'X':
                    dni = dni.replace('X', '0');
                    break;
                case 'Y':
                    dni = dni.replace('Y', '1');
                    break;
                case 'Z':
                    dni = dni.replace('Z', '2');
                    break;
                default:
                    dni = "0";
            }
            
           
        }
        
        /*
        Quitamos el último dígito del DNI, que debe ser una letra y devolvemos
        el resto de la cadena como un númerico, capturando la excepción, si la
        hubiera y devolvemos un cero, para que al analizarlo se informe de que
        no se trata de un dni correcto.
        */
        try {
            numero= Integer.parseInt(dni.substring(0, dni.length()-1));
            
            return numero; 
            
            
        } catch(NumberFormatException e) {
            
            return 0;
        }
       
        
    }
    
    /**
     * Devuelve verdadero o falso si el DNI introducido por parámetro es un
     * dni correcto (la letra coincide con el algoritmo del número para calcularla).
     * @param dni Cadena que contiene el número junto con la letra del DNI.
     * @return tipo de dato booleano que indica si el dni introducido es correcto o no.
     */
    

    public static boolean DniEsValido(String dni) {
        
        
        boolean dniValido = true;   // Suponemos el DNI válido mientras no se encuentre algún fallo
        char letraReal, letraIntroducida;
        int  dniIntroducido;

        if (dni == null) dniValido = false; // El parámetro debe ser un objeto no vacío
        else if (dni.length()!=9) dniValido = false; // El DNI completo debe tener 9 cifras entre números y letras.
        else {
            
            letraIntroducida= ValidarDatos.extraerLetraDNI(dni);    // Extraemos la letra de DNI (letra)

            dniIntroducido= ValidarDatos.extraerNumeroDNI(dni);  // Extraemos el número de DNI (int)
            
            if (dniIntroducido < 99999999) { // Analizamos si el número tiene 9 cifras o menos.
                
                letraReal= ValidarDatos.calcularLetraDNI(dniIntroducido); // Calculamos la letra de DNI a partir del número extraído
               if (letraIntroducida == letraReal) dniValido = true;  // Comparamos la letra extraída con la calculada y si es la misma la comprobación es válida
               else  dniValido = false;
               
            } else dniValido = false;
            

        }

        return dniValido;

    }
    
    //-------------------------------------------------------------
    //MÉTODO DE VALIDACIÓN DE KILÓMETROS
    
    
    /**
     * Método encargado de validar si los Kilómetros introducidos son mayores
     * que los kilómetros que anteriores.
     * 
     * @param kmsNuevos Hace referencia a los kilómetros con los que se va a actualizar
     * el vehículo
     * 
     * @param kmsActuales Hace referencia a los kilómetros actuales del vehículo.
     * @return Devuelve verdadero o falso si los kilómetros introducidos para
     * actualizar son o no correctos.
     */
    
    public static boolean kmEsValido(int kmsNuevos, int kmsActuales){
        
        return kmsNuevos > kmsActuales;
        
    }
    
    /**
     * Método encargado de validar si el número de Kilómetros introducido es mayor
     * que cero.
     * 
     * @param kms número de kilómetros a validar.
     * @return Devuelve verdadero o falso si los kilómetros introducidos son correctos.
     */
    public static boolean kmEsValido(int kms){
        
        return kms > 0;
        
    }
    
    //------------------------------------------------------------------
    //MÉTODO DE VALIDACIÓN DE FECHA DE MATRICULACIÓN
    
    /**
     * Método encargado de validar si la fecha introducida es anterior al día de hoy.
     * @param fecha fecha a evaluar.
     * @return Devuelve falso si la fecha a evaluar es posterior al día de hoy.
     */
    public static boolean fechaMatriculacionEsValida(LocalDate fecha){
        
        return fecha.isBefore(LocalDate.now());
        
    }
    
    /**
     * Método encargado de validar si el precio introducido es superior a 0
     * @param precio precio a evaluar.
     * @return Devuelve falso si el precio es menor que 0.
     */
    
    public static boolean precioEsValido(float precio){
        
        return precio > 0;
        
    }
    

}
