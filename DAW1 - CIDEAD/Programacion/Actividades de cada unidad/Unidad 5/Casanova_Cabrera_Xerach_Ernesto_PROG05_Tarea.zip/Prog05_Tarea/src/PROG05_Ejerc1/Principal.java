/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROG05_Ejerc1;

import java.util.Scanner;
import PROG05_Ejerc1_util.ValidarDatos;
import java.time.LocalDate;
import java.util.InputMismatchException;

/**
 * Clase principal del programa, se encarga de mostrar al usuario un menú
 * seleccionable del 1 al 9 en el que puede elegir la opción de crear un objeto 
 * "vehículo" o mostrar/actualizar atributos del objeto, el programa estará en
 * ejecución hasta que el usuario decida salir del mismo pulsando la tecla
 * adecuada.
 * 
 * @author Xerach E. Casanova Cabrera - DAW A
 * 
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    //static boolean vehiculoCreado = false;
    static Vehiculo vehiculo1 = null;
    
    public static void main(String[] args) throws Exception {
        
      
        System.out.println("CREADOR DE VEHÍCULOS");
        System.out.println("------------------------------------------------");
        mostrarMenu();
        
        int contadorSeleccionesMenu = 0; 
        boolean opcionSalir = false; //iniciamos la variable booleana para salir del programa en false, para que se ejecute al menos una vez.
        
        
        
        while (!opcionSalir) {
            
            String opcion; //Creamos la variable String opción, en la que guardaremos el valor de lo que el usuario introduzca por teclado.
            System.out.print("\nElige una opción: ");  
            opcion = new Scanner(System.in).nextLine();
        
            try { //capturamos la excepción si el usuario introduce un valor distinto a un número.

                int op = Integer.parseInt(opcion); //Pasamos la variable opción a una variable numérica.
                
                /* Si el usuario introduce un valor entre 1 y 8 se ejecuta el menú de opciones
                si, el valor introducido es un 9 ponemos la variable opcionSalir en true
                para salir del bucle y en cualquier otro caso se lanza un error para indicar
                que el valor introducido es incorrecto.
                */
                if (op > 0 && op < 9) {
                    opcionesMenu(op);
                    
                    /*contadorSeleccionesMenu permite que se muestre el menú en pantalla
                    cada 3 datos introducidos por el usuario, para que sea más cómoda
                    la interfaz de usuario y volvemos a resetear la variable.*/
                    
                    if (contadorSeleccionesMenu == 3) {
                
                        System.out.println("\n");
                        mostrarMenu();
                        contadorSeleccionesMenu = 0;
                
                    } //fin if (contadorSeleccionesMenu)
                    
                    contadorSeleccionesMenu++; //aumentamos la variable en cada vuelta de bucle
                    
                } //fin if (op > 0 && op < 9)
                
                else if (op == 9) opcionSalir = true;
                
                else System.out.println("Solo se admiten opciones entre 1 y 9");


            } catch(NumberFormatException e){

                System.out.println("Solo se admiten valores numéricos.");

            } //fin try-catch
            
            
            
        } 
        
        System.exit(0);
    } // fin main
 
    /**
     * Método encargado de construir el menú a visualizar por pantalla, no
     * devuelve ningún valor.
     * 
     */
    
    public static void mostrarMenu() {
    

    System.out.println("---------------------MENÚ-----------------------");
    System.out.println("1) Nuevo vehículo");
    System.out.println("2) Ver matrícula");
    System.out.println("3) Ver número de kilómetros");
    System.out.println("4) Actualizar kilómetros");
    System.out.println("5) Ver años de antigüedad");
    System.out.println("6) Mostrar propietario");
    System.out.println("7) Mostrar descripción");
    System.out.println("8) Mostrar precio");
    System.out.println("9) Salir");
}
    
    /**
     * Método encargado de manejar y ejecutar la opción introducida por el usuario
     * 
     * @param opcion Valor de la opción introducida por el usuario por teclado.
     * @throws Exception Devuelve la excepción si se elige cualquier opción que
     * pueda trabajar con el objeto vehiculo antes de haber sido creado.
     */
    public static void opcionesMenu(int opcion) throws Exception {
     
    /*
    Si el usuario introduce la opción 1 llamamos al método solicitarDatos,
    el cual se encarga de crear el objeto a partir de lo que se le pida al usuario.
    Cualquier error que el usuario cometa será capturado con un try catch.
        
    */
    if (opcion == 1) {
        
        
        try {
           solicitarDatos();
        } catch (Exception e){  
            
            System.out.println("\n" + e.getMessage() + "\n");
            
            mostrarMenu();
        }
        
    }
    else {
        /* Si el dato introducido por el usuario es distinto de 1, ejecutamos
        la opción que introduzca entre 1 y 8. El try catch se encarga de capturar
        el error si el objeto Vehiculo1 aún no ha sido inicializado.
        */
        try {
            switch (opcion) {
                   
                    case 2:
                        
                        //Mostramos la matrícula del objeto Vehiculo1
                        System.out.printf("La matrícula del vehículo es: %s\n", vehiculo1.getMatricula());
                        break; 
                        
                    case 3:
                        
                        //Mostramos los kms. del objeto Vehiculo1
                        System.out.printf("El número de kilómetros del vehículo es: %d\n", vehiculo1.getKm());  
                        break;
                        
                    case 4:
                        
                        
                        /*guardamos en una variable numérica el valor del atributo kilometros de vehiculo1.
                        Si vehiculo1 no ha sido inicializado, se captura el error antes de pedirle ningún
                        dato al usuario.
                        */
                        int kmActuales = vehiculo1.getKm();
                        
                        //Pedimos el dato de los nuevos kilómetros del coche al usuario y los guardamos en uan variable.
                        System.out.print("Introduce los nuevos Kms. del vehículo: ");
                        int kmNuevos = new Scanner(System.in).nextInt();
                        
                        /*Analizamos los kms. actuales del objeto y los kms. con los que queremos actualizar.
                        Si el valor introducido es válido (mayor que 0 y mayor que los kms que tiene almacenado el atributo
                        km del objeto (si los tuviera), se actualiza el atributo dentro del objeto
                        */
                      
                        if (ValidarDatos.kmEsValido(kmNuevos, kmActuales)){
                           vehiculo1.setKm(kmNuevos); 
                           System.out.println("Kilómetros del vehículo actualizados con éxito.");
                        }
                        /*Si el método kmEsValido devuelve false, se genera una excepción 
                        para indicar que los kms. introducidos son erroneos*/
                        
                        else throw new Exception ("El número de km. introducidos deben ser superiores a los que tiene el vehículo actualmente: " + vehiculo1.getKm());
                        
                        break;
                        
                    case 5:
                        //mostramos el valor del atributo años del objeto vehiculo1
                        System.out.printf("El vehículo tiene %s años\n", vehiculo1.get_anios());
                        break;
                        
                    case 6:
                        //mostramos el atributo propietario de vehiculo1
                        System.out.printf("El nombre del propietario del vehículo es: %s\n", vehiculo1.getPropietario());
                        break;
                        
                    case 7:
                        
                        //mostramos el valor del atributo descriocionn del objeto vehiculo1
                        System.out.printf("Descripción: %s\n", vehiculo1.getDescripcion());
                        break;
                        
                    case 8:
                        
                        //mostramos el atributo precio del objeto vehiculo1 con dos decimales.
                        System.out.printf("Precio: %.2f €\n", vehiculo1.getPrecio());
                        break;
                        

                }  // fin switch
            } catch(NullPointerException e) {
                
                // capturamos la excepción si se intenta trabajar con el objeto vehiculo1 antes de haber sido inicializado.
                System.out.println("Primero debes crear un vehículo.");
                
            } catch(Exception e){
                
                // capturamos las excepciones creadas por mi.
                System.out.println(e.getMessage());
                
            }//fin catch
        } //fin if - else
    } // fin método opciones menu
    
    
    /**
     * Método encargado de crear el objeto instanciado de la clase Vehiculo a
     * partir de los parámetros que el usuario introduce por teclado.
     * 
     * @throws Exception 
     */
    public static void solicitarDatos() throws Exception{
       
        try {
            Scanner datoIntroducido = new Scanner(System.in);
            
            //Pedimos al usuario el valor del atributo propietario del objeto.
            System.out.print("Introduce el nombre del propietario del vehículo: ");
            String propietario = datoIntroducido.nextLine();

           /*Pedimos al usuario el valor del atributo DNI del objeto 
            y llamamos al método booleano DniEsValido de la clase ValidarDatos
            para analizar si el valor devuelto es falso. Si lo fuese se
            lanza una excepción indicando que el DNI introducido es incorrecto.*/
           
           System.out.print("Introduce el DNI del propietario del vehículo: ");
           String dni = datoIntroducido.nextLine();
           if (!ValidarDatos.DniEsValido(dni)) throw new Exception ("El DNI no es correcto, introduce un DNI válido.");
           
           //Pedimos al usuario el valor del atributo marca del objeto.
           
           System.out.print("Introduce la marca del vehículo: ");
           String marca = datoIntroducido.nextLine();
           
           //Pedimos al usuario el valor del atributo descripcion del objeto.
           
           System.out.print("Introduce la descripción del vehículo: ");
           String descripcion = datoIntroducido.nextLine();
           
           //Pedimos al usuario el valor del atributo matricula del objeto.
           
           System.out.print("Introduce la matrícula del vehículo: ");
           String matricula = datoIntroducido.nextLine();
           
           //Pedimos al usuario el año, mes y día de antigüedad del vehiculo.
           
           System.out.print("Introduce el año de matriculación: ");
           int anioMatr = datoIntroducido.nextInt();
           datoIntroducido.nextLine();
     
           
           System.out.print("Introduce el mes de matriculación: ");
           int mesMatr = datoIntroducido.nextInt();
           datoIntroducido.nextLine();
           
           System.out.print("Introduce el día de matriculación: ");
           int diaMatr = datoIntroducido.nextInt();
           datoIntroducido.nextLine();
           
           /*Creamos un objeto de tipo LocalDate con las tres variables anteriores
           Y llamamos al método fechaMatriciolacionEsValida de la clase ValidarDatos
           para analizar si la fecha introducida es superior al día de hoy. Si
           devuelve false, lanzamos una excepción.
           */
           LocalDate fechaMatr = LocalDate.of(anioMatr, mesMatr, diaMatr);
           if (!ValidarDatos.fechaMatriculacionEsValida(fechaMatr)) throw new Exception ("La fecha de matriculación es posterior a la fecha actual.");
           
           
           /*Pedimos al usuario el valor del atributo kilometros del objeto vehiculo1.
           y analizamos si el valor es válido con el método kmEsValido de la clase ValidarDatos.
           En caso de que sea false lanzamos una excepción. Este método pide dos parámetros.
           Uno es los kilómetros que vamos a introducir y el otro son los kilómetros que ya tenía.
           Como estamos creando el objeto por primera vez le pasamos 0.
           */
           System.out.print("Introduce los kilómetros del vehículo: ");
           int km = datoIntroducido.nextInt();
           datoIntroducido.nextLine();
           
           if (!ValidarDatos.kmEsValido(km)) throw new Exception ("Nº de kilómetros no válido");
           
           /*Pedimos al usuario el valor del atributo precio del objeto vehiculo, si es menor que cero
           se genera una excepción.*/
           
           System.out.print("Introduce el precio del vehículo: "); 
           float precio = datoIntroducido.nextFloat();
           datoIntroducido.nextLine();
           if (!ValidarDatos.precioEsValido(precio)) throw new Exception ("El precio debe ser mayor que 0.");
           
           //Una vez pedidos todos los parámetros, inicializamos el objeto con los valores introducidos.
           vehiculo1 = new Vehiculo(marca, matricula, propietario, descripcion, km, dni, precio, fechaMatr); 
           System.out.println("\nVehículo creado con éxito\n"); 
           
           //volvemos a mostrar el menú al usuario.
           mostrarMenu();
        
        } catch (InputMismatchException e) {
            
            /*Si alguno de los datos introducidos son erroneos, como por ejemplo, que el usuario intente
            introducir una cadena en precio en vez de un valor numérico, capturamos la excepción*/
            System.out.println("\nValores incorrectos. El vehículo no ha sido creado.\n");

            
        } //fin try - catch
        

    } //fin metodo SolicitarDatos
    

} // fin clase principal


