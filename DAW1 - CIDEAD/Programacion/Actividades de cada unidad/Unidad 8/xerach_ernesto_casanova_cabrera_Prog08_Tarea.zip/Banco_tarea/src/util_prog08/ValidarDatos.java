/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util_prog08;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Esta clase se encarga de validar los datos que el usuario introduce por
 * pantalla, se recomienda manejar excepciones con el uso de los métodos de
 * esta clase.
 * 
 * @author Xerach E. Casanova Cabrera - DAW A
 */
public class ValidarDatos {
    
   
    private static final String LETRAS_DNI= "TRWAGMYFPDXBNJZSQVHLCKE";
    
    //---------------------------------------------------------------
    //MÉTODOS DE VALIDACIÓN DEL DNI
    
    /**
     * Calcula la letra del DNI sobre el número que se le pasa por parámetro.
     * 
     * 
     * @param dni número sobre el cual se calculará la letra del DNI que le corresponde.
     * @return Devuelve la letra que le corresponde al DNI de ese número concreto.
     */
    
    private static char calcularLetraDNI (int dni) {

        char letra;

        letra = LETRAS_DNI.charAt(dni % 23);       

        return letra;

    }   // fin calcularLetraDNI()
    
    /**
     * Convierte una cadena de DNI sin la letra final en tipo int, si se trata
     * de un NIE, convierte la letra del inicio en su equivalente numérico.
     * 
     * @param letraNie letra inicial del NIE
     * @param numeroDni cadena que contiene el número del DNI.
     * @return devuelve número de DNI en tipo de dato entero.
     */
    
    private static int getDniNumerico(String letraNie, String numeroDni){

        switch (letraNie) {
                case "X":
                    numeroDni = "0" + numeroDni;
                    break;
                case "Y":
                    numeroDni = "1" + numeroDni;
                    break;
                case "Z":
                    numeroDni = "2" + numeroDni;
                    break;
                default:
                    numeroDni = "0" + numeroDni;
                    break;

            } //fin sitch case
        

        return Integer.valueOf(numeroDni);
        
    } //fin getDniNUmerico()
    
    /**
     * Analiza un DNI o un NIE para analizar si se trata de un DNI válido o no,
     * si no es válido se lanza una excepción.
     * 
     * @param dni dni/nie completo, con letra, para analizar si válido.
     * @throws Exception devuelve una cadena con el error "DNI no válido".
     */
    public static void validarDNI(String dni) throws Exception{
        
        boolean dniValido = true;
        char letraReal;
        String letraNie, letraNif;
        String numeroDNI;
        
        if (dni.length()==9) {
            
            Pattern expresion = Pattern.compile("([XYZxyz]?)([0-9]{7,8})([A-Za-z])");
            Matcher cadena = expresion.matcher(dni);
            
            if (cadena.matches()) {
                
                letraNie = cadena.group(1);
                numeroDNI = cadena.group(2);
                letraNif = cadena.group(3);
                
                if (letraNif == "") dniValido = false;
                else {
               
                    letraReal = ValidarDatos.calcularLetraDNI(getDniNumerico(letraNie, numeroDNI));
            
                    if (letraReal != letraNif.charAt(0)) dniValido = false; 
                
                } //fin if - else (letraNif == "")
                
            } else dniValido = false; //fin if - else (cadena.matches())
            
            
        } else dniValido = false; //fin if - else (dni.length()==9)
        
        if (!dniValido) throw new Exception ("DNI no válido, introduzca un DNI correcto.");

    } //fin validarDNI()

    
    public static boolean NumeroCuentaEsValido(String numeroCuenta)  {
        
        Pattern expresion = Pattern.compile("ES[0-9]{20}");
        Matcher cadena = expresion.matcher(numeroCuenta);
        
        return cadena.matches();
    }

} //fin Clase ValidarDatos
