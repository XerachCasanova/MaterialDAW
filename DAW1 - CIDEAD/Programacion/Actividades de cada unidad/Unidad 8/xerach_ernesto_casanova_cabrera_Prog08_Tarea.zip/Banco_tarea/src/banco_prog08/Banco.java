/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco_prog08;

import java.util.*;

/**
 *
 * @author Xerach E. Casanova Cabrera - DAW A.
 * 
 */
public class Banco {
    
    private ArrayList<CuentaBancaria> cb;
    
    
    /**
     * Constructor de la clase Banco, crea una serie de números de cuenta de prueba
     * para poder testear el programa.
     * 
     */
    public Banco() {

        cb = new ArrayList<CuentaBancaria>();

        //cb = new CuentaBancaria[NUMERO_TOTAL_CUENTAS];

        Persona t1 = new Persona("Xerach", "Casanova Cabrera", "54050674F");
        Persona t2 = new Persona("Juan Antonio", "Pérez Ciruelo", "52369856Y");
        Persona t3 = new Persona("Laura", "Morales Pérez", "52369854G");
        cb.add(new CuentaCorrientePersonal(t1, 0, "ES12345678901234567890"));
        cb.add(new CuentaCorrienteEmpresa(t1, 6500, "ES12345678901234567891"));
        cb.add(new CuentaAhorro(t2, 6902, "ES12345678901234567892"));
        cb.add(new CuentaCorrientePersonal(t2, 2500, "ES12345678901234567893"));
        cb.add(new CuentaCorrienteEmpresa(t3, 10900, "ES12345678901234567894"));
        cb.add(new CuentaAhorro(t1, 100, "ES12345678901234567895"));
        
        //nCuentasCreadas = 6;
        
    
    }
    /**
     * Método encargado de crear objetos de tipo CuentaBancaria a partir de los
     * parámetros que recibe y devuelve true si ha sido creada correctamente.
     * @param nombre nombre del titular de la cuenta.
     * @param apellidos apellidos del titular de la cuenta.
     * @param dni DNI del titular de la cuenta.
     * @param tipoCuenta tipo de cuenta bancaria (1 - Cuenta Ahorro 2 - Cuenta Corriente Personal 3) Cuenta Corriente Empresa
     * @param numeroCuenta número de cuenta asignado a la cuenta.
     * @param saldoInicial saldo inicial con el que se genera la cuenta.
     * 
     * @return Devuelve true en caso de que la cuenta se genere correctamente.
     */
    
    public boolean crearCuentaBancaria(String nombre, String apellidos, String dni, int tipoCuenta, String numeroCuenta, double saldoInicial) {
        
        /*Llamamos al método getTitular, el cual busca dentro de las cuentas bancarias
        un titular que coincida con el dni y lo guardamos en un objeto de tipo persona.*/
        Persona titular = getTitular(dni);
        
        /*Si existe un titular que coincide con el DNI, creamos la cuenta con el 
        objeto titular obtenido*/
        if (Objects.nonNull(titular)) return crearTipoCuenta(tipoCuenta, titular, numeroCuenta, saldoInicial);
        else {
            /*Si no encuentra un titular que coincida con el DNI, creamos un 
            nuevo objeto de tipo persona y seguimos con el proceso de creación de cuenta.*/
            titular = new Persona(nombre, apellidos, dni);
            return crearTipoCuenta(tipoCuenta, titular, numeroCuenta, saldoInicial);
        }  


    }
    
    /**
     * Método que se encarga de generar objetos de tipo CuentaBancaria y guardarlos
     * en el arraylist que los almacena, esos objetos pueden ser de distintos tipos de clases
     * que heredan de CuentaBancaria, dependiendo del parámetro tipoCuenta.
     * @param tipoCuenta tipo de cuenta bancaria (1 - Cuenta Ahorro 2 - Cuenta Corriente Personal 3) Cuenta Corriente Empresa
     * @param titular titular de la cuenta bancaria.
     * @param numeroCuenta número de cuenta asignado a la cuenta.
     * @param saldoInicial  saldo inicial con el que se genera la cuenta.
     */

    private boolean crearTipoCuenta(int tipoCuenta, Persona titular, String numeroCuenta, double saldoInicial) {
        
        /*Se crean distintos tipos de objeto en el ArrayList CuentaBancaria, dependiendo
        del tipo de Cuenta que se haya asignado.*/
        
        switch(tipoCuenta){
                
            case 1:
                
                cb.add(new CuentaAhorro(titular, saldoInicial, numeroCuenta));
                
                break;
            case 2:
                
                cb.add(new CuentaCorrientePersonal(titular, saldoInicial, numeroCuenta));
                
                break;
            case 3:
                
                cb.add(new CuentaCorrienteEmpresa(titular, saldoInicial, numeroCuenta));
                
                break;
                
            
        }
        
        return true;
        
    }
    
    /**
     * Método privado de la clase Banco que devuelve objetos de tipo Cuenta Bancaria
     * a partir de un número de cuenta que se pase por parámetro.
     * 
     * @param numeroCuenta
     * @return  objeto de tipo CuentaBancaria. Devuelve null en caso de no encontrar.
     */
    private CuentaBancaria getCuentaBancaria(String numeroCuenta) {
        /*Recorremos el arraylist donde almacenamos las cuentas bancarias y
        si encuentra una cuenta en la que coincida el número de cuenta
        proporcionado por parámetros, lo devolvemos. Si no encuentra ninguna
        cuenta devuelve null.*/
        
        for (CuentaBancaria cuenta : cb)
            
            if (cuenta.getNumeroCuenta().equals(numeroCuenta)) return cuenta;

            return null;
        
        
    }
    /**
     * Método que devuelve la cantidad de cuentas bancarias que hay asignadas
     * a un mismo titular a partir del dni que se le pasa por parámetro. 
     * @param dni DNI a analizar en busca de cuentas bancarias asociadas a él.
     * @return cantidad de cuentas bancarias asignadas a un usuario. Devuelve 
     * cero si no encuentra ninguna.
     */
    public int cantidadCuentasUsuario(String dni) {
        int nCuentasUsuario = 0;

        for (CuentaBancaria cuenta : cb)
            if (cuenta.getTitular().getDni().equals(dni))  nCuentasUsuario++;
   
        return nCuentasUsuario;
        

    }
    /**
     * Método encargado de devolver un array de Strings con todas las cuentas
     * que existen en el ArrayList de tipo CuentaBancaria, lanza una excepción si no
     * existen cuentas bancarias creadas.
     * @return Array de string con los datos de cada una de las cuentas en cada fila del array.
     * @throws Exception Lanza una excepción si no hay cuentas creadas.
     */
    public String[] listadoCuentas() throws Exception {
        /*Si no encuentra cuentas lanzamos una excepción.*/
        if (cb.size()==0) throw new Exception ("No hay cuentas creadas.");
   
        /*Creamos un array del tamaño del total de cuentas creadas y un contador
        para poder recorrer el array y meter dentro de cada elemento la información
        de cada cuenta.*/
        
        String[] cuentas = new String[cb.size()];
        int contador=0;
        
        for (CuentaBancaria cuenta : cb){
            
            cuentas[contador] = cuenta.devolverInfoString();
            contador++;
        }
        return cuentas;
        
    }
    
    /**
     * Devuelve una cadena con la información de una cuenta determinada a partir
     * del número de cuenta que se le pasa por parámetro.
     * 
     * @param numeroCuenta Número de cuenta de la cual se quiere obtener información
     * 
     * @return cadena con la información de una cuenta determinada.
     * 
     * @exception lanza una excepción si la cuenta no existe.
     */
    public String informacionCuenta(String numeroCuenta) throws Exception {
        
        /*llamamos al método qeu se encarga de buscar cuentas pasándole
        el número de cuenta.*/
        CuentaBancaria cuenta = getCuentaBancaria(numeroCuenta);

        if (Objects.isNull(cuenta)) throw new Exception ("La cuenta no existe.");
        
        /*si encuentra la cuenta se devuelve una cadena generada por el método
        devolverInfoString del objeto de tipo CuentaBancaria*/
        return cuenta.devolverInfoString();
   

    }
    
    /**
     * Devuelve true si encuentra una cuenta bancaria que coincida con el número
     * de cuenta que se pasa por parámetro.
     * 
     * @param numeroCuenta número de cuenta a buscar.
     * 
     * @return Devuelve true si encuentra un número de cuenta.
     * 
     * @throws Exception Lanza una excepción si no encuentra un número de cuenta.
     */
    public boolean existeCuentaBancaria(String numeroCuenta){
        
        CuentaBancaria cuenta = getCuentaBancaria(numeroCuenta);
        
        if (Objects.isNull(cuenta)) return false; 
        
        return true;
    
    }
    
    /**
     * Devuelve el saldo actual de una cuenta bancaria existente en el arraylist
     * de tipo CuentaBancaria a partir del número de cuenta que se le pasa por
     * parámetro. 
     * 
     * @param numeroCuenta a buscar en el ArrayList.
     * 
     * @return devuelve el saldo actual de una cuenta determinada.
     * 
     * @throws Exception Lanza una excepción si el número de cuenta no existe.
     */
    public double getSaldoCuentaBancaria(String numeroCuenta) throws Exception{
        CuentaBancaria cuenta = getCuentaBancaria(numeroCuenta);
        
        //si no encuentra una cuenta bancaria lanza una excepción
        if (Objects.isNull(cuenta)) throw new Exception ("El número de cuenta no existe.");

        return cuenta.getSaldo();
        
    }
    
    /**
     * Método encargado de devolver un array de String con los números de cuenta
     * pertenecientes a un cliente concreto a partir del dni pasado por parámetro.
     * 
     * @param dni dni del cliente del que se quieren obtener las cuentas bancarias
     * asignadas a él.
     * 
     * @return  array de strings con los números de cuenta pertenecientes al cliente.
     */
    
    public String[] listadoNumerosCuentaUsuario(String dni) {
        
        
        ArrayList<CuentaBancaria> cuentasDni = new ArrayList<CuentaBancaria>();
        
        /*recorremos el arraylist en busca de un cliente que coincida con el DNI y
        cada vez que encuentra una la almacenamos en otra lista*/
                
        for (CuentaBancaria cuenta : cb) 
             if (cuenta.getTitular().getDni().equals(dni)) cuentasDni.add(cuenta);
        
        String[] numerosCuenta = null;
        
        /*Si se almacenaron en el arraylist cuentas que coinciden con el dni
        creamos un ArrayList de String del tamaño de la nueva lista de cuentas 
        (las pertenecientes al dni) y recorremos la lista para obtener los
        números de cuenta de cada uno de sus elementos guardándolos en un
        array de String*/
        if (cuentasDni.size() > 0) {
            
            int contador = 0;
            numerosCuenta = new String[cuentasDni.size()];
            for (CuentaBancaria cuenta : cuentasDni){
                
                numerosCuenta[contador] = cuenta.getNumeroCuenta();
                contador++;
                
            }
        
        }
        
        return numerosCuenta;

    }
    
    /**
     * Método encargado de devolver un array con los datos personales del titular
     * de una cuenta a partir del DNI que se le pasa por parámetro
     * 
     * @param dni DNI del cliente a buscar.
     * 
     * @return Devuelve un string con los datos del titular de la cuenta.
     */
    public String[] getDatosTitularCuenta(String dni) {
        
        /*Buscamos un cliente con el que coincida el DNI */
        String[] titular = null;
        
        for (CuentaBancaria cuenta : cb) 
            // Si encuentra una coincidencia guarda en un array de String los datos del titular.
            if (cuenta.getTitular().getDni().equals(dni)){
                titular = new String[3];
                
                titular[0] = cuenta.getTitular().getNombre();
                titular[1] = cuenta.getTitular().getApellidos();
                titular[2] = cuenta.getTitular().getDni();
            }
        
        return titular;
        
       
    }
    /**
     * Método que devuelve un objeto titular a partir del DNI que se
     * le pasa por parámetro, para mantener el principio, este objeto es una
     * copia para garantizar el principio de ocultación.
     * 
     * @param dni DNI del cliente a buscar.
     * 
     * @return Devuelve un objeto de tipo Persona con los datos del titular.
     */
    
    private Persona getTitular(String dni){
        
        Persona titular = null;
        
        for (CuentaBancaria cuenta : cb)
            
            if (cuenta.getTitular().getDni().equals(dni)) return cuenta.getTitular();
            
        return titular;
        
        
    }
    
    /**
     * Método encargado de realizar un ingreso en cuenta a partir del número de cuenta
     * recibido por parámetro y el importe a ingresar.
     * 
     * @param numeroCuenta numero de cuenta en el que se va a realizar un ingreso.
     * @param importe importe en positivo del ingreso a realizar.
     * 
     * @return devuelve true si se realiza el ingreso correctamente.
     * 
     * @throws Exception Lanza una excepción si la cantidad a ingresar es un número en negativo
     */
    
    public boolean ingresoCuenta(String numeroCuenta,double importe) throws Exception {
        
        /*Generamos una excepción si la cantidad de ingreso insertada es negativa.*/
        if (importe < 0) throw new Exception ("La cantidad a ingresar no puede ser negativa.");
        
        /*Buscamos la cuenta bancaria en el ArrayList a partir del número de cuenta pasado por parámetros.*/
        CuentaBancaria cuenta = getCuentaBancaria(numeroCuenta);
        
        //setteamos el nuevo importe del saldo añadiéndolo al ya existente.
        cuenta.setSaldo(cuenta.getSaldo() + importe);

        return true;
    }
    
    /**
     * Método encargado de realizar una retirada en cuenta a partir del número de cuenta
     * recibido por parámetro y el importe a retirar, si el tipo de cuenta es de empresa
     * permitirá retiradas de efectivo con la cuenta en negativo, este método se encarga
     * de calcular la comisión e intereses de la retirada de efectivo con la cuenta al
     * descubierto.
     * 
     * @param numeroCuenta numero de cuenta en el que se va a realizar una retirada.
     * @param importe importe en positivo de la retirada a realizar.
     * 
     * @return devuelve true si se realiza la retirada correctamente.
     * 
     * @throws Exception Lanza una excepción si la cantidad a retirar es un número en negativo
     */
    
    public boolean retiroCuenta(String numeroCuenta, double importe) throws Exception {
        
        /*Generamos una excepción si la cantidad de ingreso insertada es negativa.*/
        
        if (importe < 0) throw new Exception ("La cantidad a ingresar o retirar no puede ser negativa.");
     
        CuentaBancaria cuenta = getCuentaBancaria(numeroCuenta);
        
        /*Analizamos si el tipo de cuenta guardado en el ArrayList es una instancia
        de CuentaCorrienteEmpresa*/
        if(cuenta instanceof CuentaCorrienteEmpresa) {
            
            /*Llamamos al método encargado de calcular la comisión e intereses
            en caso que se haga una retirada de efectivo que deje la cuenta
            en descubierto o en caso de que la cuenta ya esté en descubierto
            actualmente. */
            cobroComisionDescubEmpresa(cuenta, importe);
        
        /*Si no es cuenta de empresa no permitimos la retirada de efectivo y lanzamos
        una excepción*/
        }else if (cuenta.getSaldo() - importe < 0) throw new Exception ("Operación denegada. La cuenta seleccionada no permite saldo descubierto.");
        
        /*Si la cuenta no es de empresa, pero la cantidad a retirar no supera al saldo actual
        permitimos la retirada.*/
        else cuenta.setSaldo(cuenta.getSaldo() - importe);
  
        return true;
    }
    
    /**
     * Método encargado de llamar al método encargado del objeto CuentaCorrienteEmpresa
     * que se encarga de calcular la comisión y el tipo de interés a cobrar al cliente en
     * caso de tener un descubierto en cuenta.
     * 
     * @param cuenta cuenta bancaria en la que se va realizar el cálculo
     * @param importe importe a retirar
     * 
     * @throws Exception Lanza una excepción si el importe a retirar + la comisión generada
     * supera al importe máximo descubierto de la cuenta.
     */
    private void cobroComisionDescubEmpresa(CuentaBancaria cuenta, double importe) throws Exception {
        
        //*Guardamos en una variable el resultado del cálculo de la comisión a cobrar.
        double comisionDescubierto = ((CuentaCorrienteEmpresa) cuenta).cobrarComision(importe);
        
        //*Guardamos en una variable el máximo descubierto permitido para la cuenta.
        double maximoDescubiertoPermitido = ((CuentaCorrienteEmpresa) cuenta).getMaxDescubiertoAllowed();
        
        /*guardamos en una variable el resultado del saldo actual menos 
        el importe a retirar y la comisión por descubierto */
        
        double totalADescontar = cuenta.getSaldo() - importe - comisionDescubierto;
        
        /*Si el total del cálculo de la comisión a cobrar  + el saldo a retirar supera 
        el máximo descubierto permitido lanzamos una excepción que impida hacer la retirada.*/
        if (totalADescontar < 0 && maximoDescubiertoPermitido > totalADescontar) {
            throw new Exception ("Operación denegada. El importe a retirar + la comisión generada supera el máximo descubierto permitido.");
        }
        
        //Setteamos el saldo de la cuenta restando la cantidad a retirar y la comisión.
        cuenta.setSaldo(cuenta.getSaldo() - importe - comisionDescubierto);
    }
    
    
    public boolean eliminarCuentaBancaria(String numeroCuenta){

        int i = 0;
        
        while (i <cb.size()){
            
            if (cb.get(i).numeroCuenta.equals(numeroCuenta) && cb.get(i).getSaldo()==0) {
                
                cb.remove(i);
                return true;
                
            }
            i++;
            
        }
        
        return false;

        
        
    }
  

}
