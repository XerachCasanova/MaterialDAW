
package banco_prog08;

/**
 * Superclase de tipo CuentaBancaria de la cual heredan los distintos
 * tipos de cuenta corriente existentes en el programa.
 * 
 * @author Xerach E. Casanova Cabrera - DAW A
 */
abstract public class CuentaBancaria implements Imprimible {
    
    protected Persona titular;
    protected double saldo;
    protected String numeroCuenta;
    
    /**
     * * Constructor de objetos de tipo CuentaBancaria, se inicializa con un objeto
     * de tipo persona, saldo inicial y número de cuenta asignado.
     * 
     * @param titular titular de la cuenta bancaria.
     * @param saldo saldo actual de la cuenta bancaria.
     * @param numeroCuenta número asignado a la cuenta bancaria.
     */
    public CuentaBancaria(Persona titular, double saldo, String numeroCuenta) {
        
 
        this.titular = titular;
        this.saldo = saldo;
        this.numeroCuenta = numeroCuenta;
    }
    
    /**
     * Método getter que se encarga de devolver objetos de tipo titular garantizando
     * la ocultación del propio objeto, ya que devuelve una copia del mismo.
     * @return 
     */
    public Persona getTitular() {
        
        return new Persona(this.titular);
        
    }
    
    /**
     * Método getter del atributo saldo del objeto CuentaBancaria.
     * @return devuelve una variable de tipo double del atributo saldo.
     */

    public double getSaldo() {
        return saldo;
    }
    
    /**
     * Método setter del atributo saldo del objeto CuentaBancaria.
     * @param saldo saldo a settear.
     */
   
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    /**
     * Método getter del atributo numeroCuenta del objeto CuentaBancaria.
     * @return devuelve una variable de tipo String del atributo numeroCuenta.
     */

    public String getNumeroCuenta() {
        return numeroCuenta;
    }
    
    /**
    * Método perteneciente a la interfaz Imprimible, que se encarga de devolver
    * un string que contiene la información de los distintos datos de la cuenta,
    * cada dato es separado por el carácter |
    *
    * @return cadena de caracteres con los datos de la cuenta.
    */

    @Override
    public String devolverInfoString(){
        
        String imprimir = 
            "Número de cuenta: " + getNumeroCuenta() + " | " +
            getTitular().devolverInfoString() + " | " + 
            "Saldo disponible: " + getSaldo();
        
        return imprimir;
        
    }
    
    
    
}
