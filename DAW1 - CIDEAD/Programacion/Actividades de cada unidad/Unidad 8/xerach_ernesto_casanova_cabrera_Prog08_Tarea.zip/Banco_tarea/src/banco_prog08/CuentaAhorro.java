/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco_prog08;

import java.text.DecimalFormat;

/**
 * Clase de tipo CuentaAhorro que hereda de la clase CuentaBancaria.
 * 
 * @author Xerach E. Casanova Cabrera - DAW A
 */

public class CuentaAhorro extends CuentaBancaria implements Imprimible {
    
    private float tipoInteresRemunerado; 
    
    /**
     * Constructor de objetos de tipo CuentaAhorro, hereda los atributos
     * de su clase padre CuentaBancaria, además asigna al atributo tipoInteresRemunerado 
     * un valor por defecto de 0.015.
     * 
     * @param titular titular de la cuenta bancaria.
     * @param saldo saldo actual de la cuenta bancaria.
     * @param numeroCuenta número asignado a la cuenta bancaria.
     */
    
    public CuentaAhorro(Persona titular, double saldo, String numeroCuenta) {
        super(titular, saldo, numeroCuenta);
        
        tipoInteresRemunerado = 0.015F;
        
    }
    
     /**
     * Constructor de objetos de tipo CuentaAhorro, hereda los atributos
     * de su clase padre CuentaCorriente y además inicializa sus atributos propios
     * con los parámetros pasados.
     * 
     * @param titular titular de la cuenta bancaria.
     * @param saldo saldo actual de la cuenta bancaria.
     * @param numeroCuenta número asignado a la cuenta bancaria.
     * @param tipoInteresRemunerado tipo de interés remunerado anual en la cuenta bancaria.

     */
    
    public CuentaAhorro(Persona titular, double saldo, String numeroCuenta, float tipoInteresRemunerado) {
        super(titular, saldo, numeroCuenta);
       
        this.tipoInteresRemunerado = tipoInteresRemunerado;
        
    }
    
    /**
     * Método que cuando es llamado se encarga de aplicar al saldo actual un interés
     * añadido, súmandole el porcentaje guardado en el atributo tipoInteresRemunerado.
     * @return 
     */
    public double aplicarInteresRemunerado(){
        
        return saldo = saldo + saldo*tipoInteresRemunerado;
      
    }
    
    /**
     * Método getter del tipoInteresRemunerado del objeto CuencaAhorro.
     * @return devuelve una variable de tipo float del atributo tipoInteresRemunerado
     */
    
    public float getTipoInteresRemunerado() {
        return tipoInteresRemunerado;
    }
    
    /**
     * Método setter del atributo tipoInteresRemunerado del objeto CuentaAhorro.
     * @param tipoInteresRemunerado tipo de interés remunerado a settear.
     */

    public void setTipoInteresRemunerado(float tipoInteresRemunerado) {
        this.tipoInteresRemunerado = tipoInteresRemunerado;
    }
    
    @Override
    public String devolverInfoString() {
        DecimalFormat df = new DecimalFormat("0.00");
        String imprimir = 
            "Número de cuenta: " + getNumeroCuenta() + " | " +
            "Tipo de cuenta: Cuenta de ahorro |" +
            getTitular().devolverInfoString() + " | " + 
            "Saldo disponible: " + df.format(getSaldo()) + " | " + 
            "Comisión por descubierto: " + df.format(getTipoInteresRemunerado()); 
        
        return imprimir;
        
    }
    
}
