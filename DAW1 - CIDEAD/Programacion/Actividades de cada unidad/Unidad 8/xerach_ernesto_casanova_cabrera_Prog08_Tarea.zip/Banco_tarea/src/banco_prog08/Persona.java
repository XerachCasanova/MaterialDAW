/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco_prog08;

/**
 *
 * @author Xerach E. Casanova Cabrera - DAW A.
 */
public class Persona implements Imprimible {
    
    private String nombre;
    private String apellidos;
    private String dni;
    
    /**
     * Constructor de objetos de tipo persona.
     * @param nombre nombre de la persona.
     * @param apellidos apellidos de la persona.
     * @param dni dni de la persona.
     */
   
    public Persona(String nombre, String apellidos, String dni) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
    }
    
    /**
     * Contructor copia
     * Crea un objeto de tipo persona idéntico al objeto de tipo persona que
     * recibe por parámetros.
     * 
     * @param p Objeto de tipo persona a duplicar.
     */
    public Persona(Persona p){
        
        nombre = p.getNombre();
        apellidos = p.getApellidos();
        dni = p.getDni();
        
    }
    
    /**
     * Método getter del atributo nombre del objeto persona.
     * @return devuelve un String con el atributo del nombre de la persona.
     */
    public String getNombre() {
        return nombre;
    }
    
    /**
     * Método getter del atributo nombre del objeto apellidos.
     * @return devuelve un String con el atributo los apellidos de la persona.
     */
    
    
    public String getApellidos() {
        return apellidos;
    }
    
    /**
     * Método getter del atributo dni del objeto persona.
     * @return devuelve un String con el atributo del dni de la persona.
     */
    
    public String getDni() {
        return dni;
    }
    
    /**
     * Método setter del atributo nombre del objeto persona.
     * 
     * @param nombre nombre a settear.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    /**
     * Método setter del atributo apellidos del objeto persona.
     * 
     * @param apellidos apellidos a settear.
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    
    /**
     * Método setter del atributo dni del objeto persona.
     * 
     * @param dni dni a settear.
     */
    public void setDni(String dni) {
        this.dni = dni;
    }
    
    /**
     * Método perteneciente a la interfaz Imprimible, que se encarga de devolver
     * un string que contiene la información de los distintos datos personales
     * de cada persona del objeto Persona, cada dato es separado por el carácter |
     * 
     * @return cadena de caracteres con los datos de la persona.
     */
    @Override
    public String devolverInfoString() {
        
        String imprimir = 
            "Nombre del cliente: " + getNombre() + " "+ getApellidos() + " | " +
            "DNI: " + getDni();
        
        return imprimir;
        
    }
    
}
