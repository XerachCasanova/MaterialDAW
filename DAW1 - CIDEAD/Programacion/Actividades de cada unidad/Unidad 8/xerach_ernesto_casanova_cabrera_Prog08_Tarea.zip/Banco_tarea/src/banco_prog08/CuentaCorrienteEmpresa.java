/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco_prog08;

import java.text.DecimalFormat;

/**
 * Clase que genera objetos de tipo CuentaCorrienteEmpresa, que hereda a su vez
 * de la Clase abstracta CuentaCorriente.
 * 
 * @author Xerach E. Casanova Cabrera - DAW A.
 */
public class CuentaCorrienteEmpresa extends CuentaCorriente {
    
    private double maxDescubiertoAllowed;
    private float tipoInteres;
    private float comision;
    
    /**
     * * Constructor de objetos de tipo CuentaCorrienteEmpresa, hereda los atributos
     * de su clase padre CuentaCorriente, además asigna a valores por defecto a los
     * siguientes atributos: maxDescubiertoAllowed (-2000), comisión (5) y tipoInteres (0.15).
     * un valor por defecto
     * de 30.
     * 
     * @param titular titular de la cuenta bancaria.
     * @param saldo saldo actual de la cuenta bancaria.
     * @param numeroCuenta número asignado a la cuenta bancaria.
     */
    public CuentaCorrienteEmpresa(Persona titular, double saldo, String numeroCuenta) {
        super(titular, saldo, numeroCuenta);
        
        maxDescubiertoAllowed = -2000;
        comision = 5F;
        tipoInteres = 0.15F;
       
    }
    /**
     * Constructor de objetos de tipo CuentaCorrienteEmpresa, hereda los atributos
     * de su clase padre CuentaCorriente y además inicializa sus atributos propios
     * con los parámetros pasados.
     * 
     * @param titular titular de la cuenta bancaria.
     * @param saldo saldo actual de la cuenta bancaria.
     * @param numeroCuenta número asignado a la cuenta bancaria.
     * @param maximoDescubiertoPermit máximo descubierto permitido para la cuenta.
     * @param tipoInteres tipo de interés para descubiertos en cuenta.
     * @param comision comisión para descubierto en cuenta.
     */
    
    public CuentaCorrienteEmpresa(Persona titular, double saldo, String numeroCuenta, double maximoDescubiertoPermit, float tipoInteres, float comision) {
        super(titular, saldo, numeroCuenta);
        this.maxDescubiertoAllowed = maximoDescubiertoPermit;
        this.tipoInteres = tipoInteres;
        this.comision = comision;
        
        
    }

    /**
     * Método que devuelve el importe de interés + comisión para una retirada
     * de efectivo en la que el saldo de la cuenta está actualmente en negativo
     * o estará después de realizar el movimiento en cuenta, si el saldo
     * está en positivo y queda en negativo con el movimiento de efectivo que
     * se le pasa por parámetro, se devuelve la comisión a cobrar por entrar
     * en descubierto + el interés, si el saldo actual ya es negativo, se devuelve el tipo
     * de interés generado sobre el movimiento en negativo.
     * 
     * @param movimiento cantidad de dinero a retirar de la cuenta.
     * 
     * @return Devuelve un valor de tipo double que contiene el porcentaje de comisión
     * que se debe restar de la cuenta en base al descubierto de la cuenta y al movimiento
     * que se está realizando.
     */
    public double cobrarComision(double movimiento) {
        
        
        double cobroComision = 0;
        /*Si el saldo actual de la cuenta es positivo pero el saldo - el movimiento
        a realizar deja la cuenta en negativo, realizamos el cálculo de la comisión 
        a cobrar en varios pasos.*/
        if (saldo >= 0 && saldo - movimiento < 0) {
            /*Primero calculamos en cuanto se quedaría el saldo de la cuenta
            restándole el movimiento a realizar y la comisión.*/
            cobroComision = saldo - movimiento - comision;
            /*Después calculamos el tipo de interés sobre el resultado anterior.*/
            cobroComision = cobroComision*-tipoInteres;
            /*Por último, le sumamos al tipo de interés generado, la comisión por
            entrar en descubierto.*/
            cobroComision = cobroComision + comision;
            return cobroComision;
        }
        
        /*Si el saldo actual ya era menor que cero, no cobramos comisión, pero sí
        intereses sobre el movimiento.*/
        else if (saldo < 0) return (movimiento) * tipoInteres;
        
        /*Si el saldo es positivo y sigue quedando en positivo después del movimiento
        no generamos interés.*/
        else return 0;
 
    }
    
    /**
     * Método getter del atributo maxDescubiertoAllowed del objeto CuencaCorrienteEmpresa.
     * @return devuelve una variable de tipo double del atributo maxDescubiertoAllowed
     */
    
    public double getMaxDescubiertoAllowed() {
        
        return maxDescubiertoAllowed;
        
    }
    
    /**
     * Método setter del atributo maxDescubiertoAllowed del objeto CuencaCorrienteEmpresa.
     * @param tipoInteres máximo descubierto permitido a settear.
     */
    
    public void setMaxDescubiertoAllowed(double maxDescubiertoAllowed) {
        
        this.maxDescubiertoAllowed = maxDescubiertoAllowed;
    }
    
    /**
     * Método getter del atributo tipoInteres del objeto CuencaCorrienteEmpresa.
     * @return devuelve una variable de tipo float del atributo tipoInteres
     */

    public float getTipoInteres() {
        return tipoInteres;
    }
    
    /**
     * Método setter del atributo tipoInteres del objeto CuencaCorrienteEmpresa.
     * @param tipoInteres tipo de interés a settear.
     */
    public void setTipoInteres(float tipoInteres) {
        this.tipoInteres = tipoInteres;
    }
    
    /**
     * Método getter del atributo comision del objeto CuencaCorrienteEmpresa.
     * @return devuelve una variable de tipo float del atributo comision
     */
    
    public float getComision() {
        return comision;
    }
    
    /**
     * Método setter del atributo comision del objeto CuencaCorrienteEmpresa.
     * @param comision comisión a settear.
     */
    public void setComision(float comision) {
        this.comision = comision;
    }
    
    @Override
    public String devolverInfoString() {
        DecimalFormat df = new DecimalFormat("0.00");
        
        String imprimir = 
            "Número de cuenta: " + getNumeroCuenta() + " | " +
            "Tipo de cuenta: Cuenta de empresa |" +
            getTitular().devolverInfoString() + " | " + 
            "Saldo disponible: " + df.format(getSaldo()) + " | " + 
            "Comisión por descubierto: " + df.format(getComision()) + " | " + 
            "tipo de interés por descubierto: " + df.format(getTipoInteres());
        
        return imprimir;
        
    }
    
    
}
