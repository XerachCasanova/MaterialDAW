/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

import java.text.DecimalFormat;

/**
 * Clase que genera objetos de tipo CuentaCorrientePersonal, que hereda a su vez
 * de la Clase abstracta CuentaCorriente.
 * 
 * @author Xerach E. Casanova Cabrera - DAW A. 
 */
public class CuentaCorrientePersonal extends CuentaCorriente {
    
    private float comisionAnual;
    
    /**
     * Constructor de objetos de tipo CuentaCorrientePersonal, hereda los atributos
     * de su clase padre CuentaCorriente, además asigna al atributo comisionAnual un valor por defecto
     * de 30.
     * 
     * @param titular titular de la cuenta bancaria.
     * @param saldo saldo actual de la cuenta bancaria.
     * @param numeroCuenta número asignado a la cuenta bancaria.
     */
    public CuentaCorrientePersonal(Persona titular, double saldo, String numeroCuenta) {
        super(titular, saldo, numeroCuenta);
        
        comisionAnual = 30;
        
    }
    
    /**
     * Constructor de objetos de tipo CuentaCorrientePersonal, hereda los atributos
     * de su clase padre CuentaCorriente y además inicializa sus atributos propios
     * con los parámetros pasados.
     * 
     * @param titular titular de la cuenta bancaria.
     * @param saldo saldo actual de la cuenta bancaria.
     * @param numeroCuenta número asignado a la cuenta bancaria.
     * @param comisionAnual Comisión anual para la cuenta bancaria.
     */
    
    public CuentaCorrientePersonal(Persona titular, double saldo, String numeroCuenta, float comisionAnual) {
        super(titular, saldo, numeroCuenta);
        
        this.comisionAnual = comisionAnual;
    }
    
    /**
     * Método encargado de realizar un cargo en cuenta de la comisión anual por defecto
     * cuando es llamada.
     * 
     * @return devuelve la cantidad de saldo resultante después de restarle la comisión.
     */
    public double cobrarComision() {

      return saldo = saldo - comisionAnual;  
    }
    
    /**
     * Método getter del atributo comisionAnual del objeto CuencaCorrientePersonal.
     * @return devuelve una variable de tipo float  del atributo comisionAnual
     */
    public float getComisionAnual() {
        return comisionAnual;
    }
    
     /**
     * Método setter del atributo comisionAnual del objeto CuencaCorrientePersonal.
     * @param comisionAnual comisión anual a settear.
     */
    public void setComisionAnual(float comisionAnual) {
        this.comisionAnual = comisionAnual;
    }
    
    /**
    * Método perteneciente a la interfaz Imprimible, que se encarga de devolver
    * un string que contiene la información de los distintos datos de la cuenta,
    * cada dato es separado por el carácter |
    *
    * @return cadena de caracteres con los datos de la cuenta.
    */
    
    @Override
    public String devolverInfoString() {
        DecimalFormat df = new DecimalFormat("0.00");
        String imprimir = 
            "Número de cuenta: " + getNumeroCuenta() + " | " +
            "Tipo de cuenta: Cuenta corriente Personal |" +
            getTitular().devolverInfoString() + " | " + 
            "Saldo disponible: " + df.format(getSaldo()) + " | " + 
            "Comisión por descubierto: " + df.format(getComisionAnual()); 
        
        return imprimir;
        
    }
    
    
}
