/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

/**
 *
 * @author Xerach E. Casanova Cabrera - DAW A.
 * 
 */
interface Imprimible {
    
    /**
     * Método perteneciente a la interfaz imprimible para generar información
     * de tipo String en la clase que lo implementa.
     * @return 
     */
    String devolverInfoString();
    
}
