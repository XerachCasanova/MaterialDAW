/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

import util.ValidarDatos;

/**
 * Clase abstracta de tipo CuentaCorriente de la cual heredan los distintos
 * tipos de cuenta corriente existentes en el programa y que a su vez hereda
 * de la clase CuentaBancaria.
 * 
 * @author Xerach E. Casanova Cabrera - DAW A
 */
abstract public class CuentaCorriente extends CuentaBancaria{
   
    protected final int MAX_ENTIDADES = 50;
    protected int nEntidadesTotales;
    protected String[] entidades;
    
    /**
     * Constructor de la clase abstracta CuentaCorriente, que hereda los atributos
     * de su clase padre CuentaBancaria, además crea por defecto cinco entidades
     * distintas de prueba y son almacenadas en el atributo array  entidades, contiene
     * un atributo entidades de tipo Array de String que almacena el número de cuenta
     * de hasta 50 entidades que tienen permitido hacer cobros en cada cuenta.
     * 
     * @param titular titular de la cuenta bancaria.
     * @param saldo saldo actual de la cuenta bancaria.
     * @param numeroCuenta número asignado a la cuenta bancaria.
     */
    public CuentaCorriente(Persona titular, double saldo, String numeroCuenta) {
        super(titular, saldo, numeroCuenta);
        /* Creo cinco entidades de prueba. */
        entidades = new String[MAX_ENTIDADES];
        entidades[0] = "ES00000000000000000001";
        entidades[1] = "ES00000000000000000002";
        entidades[2] = "ES00000000000000000003";
        entidades[3] = "ES00000000000000000004";
        entidades[4] = "ES00000000000000000005";
        nEntidadesTotales=5;
        
    }
    
    /**
     * Método addEntidades, encargado de añadir entidades a cada objeto CuentaCorriente,
     * asignándole un número de cuenta pasado por parámetros.
     * @param numeroCuenta número de cuenta de la nueva entidad.
     * 
     * @return devuelve true si la entidad se genera correctamente.
     * @throws Exception Lanza una excepción si el array está lleno
     * o si el número de cuenta no tiene un formato válido..
     */
    public boolean addEntidades(String numeroCuenta) throws Exception {
        
        if (entidades.length == MAX_ENTIDADES) throw new Exception ("No se pueden añadir más entidades de cobro.");
        else if (!ValidarDatos.NumeroCuentaEsValido(numeroCuenta)) throw new Exception ("El número de cuenta de la entidad a introducir no es correcto.");
        else entidades[nEntidadesTotales] = numeroCuenta;
        
        return true;
    }
    
    /**
     * Método deleteEntidades, encargado de eliminar entidades a cada objeto CuentaCorriente,
     * y reordenar el array si el elemento eliminado es un elemento que se encuentra
     * entre medio de otros.
     * @param numeroCuenta número de cuenta de la entidad a eliminar.
     * 
     * @return devuelve true si la entidad se elimina correctamente.
     * @throws Exception Lanza una excepción si el elemento a eliminar no existe.
     */
    
    public boolean deleteEntidades(String numeroCuenta) throws Exception {
        int posicionBorrada = -1;
        /*Recorre el array en búsca de la entidad y si la encuentra la borra y
        guarda en una variable su posición.*/
        for (int i = 0; i< nEntidadesTotales; i++){
            
            if (entidades[i].equals(numeroCuenta)) {
                entidades[i] = null;
                posicionBorrada = i;
            }
            
        }
        
        if (posicionBorrada == -1) throw new Exception ("El número de cuenta no existe");
        
        /*recorremos el array a partir de la posición en la que eliminamos la entidad
        y le asignamos el contenido de la posición siguiente.*/
        for (int i =posicionBorrada; i<nEntidadesTotales; i++) {
            
            entidades[i] = entidades[i+1];
    
        }
        
        return true;

    }
    
    
    
    
    
    
}
