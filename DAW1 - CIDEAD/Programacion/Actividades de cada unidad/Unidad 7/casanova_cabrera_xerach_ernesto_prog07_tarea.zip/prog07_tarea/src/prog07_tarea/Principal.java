package prog07_tarea;

import banco.*;
import java.util.*;
import util.ValidarDatos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Xerach
 */


public class Principal {

    final static int NUMERO_OPCIONES = 7;

    static Banco banco;
 
    public static void main(String[] args) {
        // TODO code application logic here

        banco = new Banco();
        System.out.println("****************Banco El buitre negro****************");
        System.out.println("---------------Tu dinero nos pertenece---------------");
        System.out.println("-------------(y el de tus hijos también)-------------\n");

        eleccionMenu();

    }
    
    /**
     * Método encargado de mostrar el menú del programa y analizar la opción 
     * elegida por el usuario y ejecutar la opción elegida o devolver error en 
     * caso de que sea una opción incorrecta.
     * 
     */
    public static void eleccionMenu() {
        int opcion;
        mostrarMenu();

        do {
            try {

                opcion = new Scanner(System.in).nextInt();
                /*
                Si la opción elegida es menor que cero y mayor que el número
                de opciones asignado en la constante, se genera una excepción
                y si no, se ejecuta el método ejecutarOpcionesMenu y se asigna
                la variable opción a cero para forzar la repetición del bucle.
                */
                if (opcion < 1 || opcion > NUMERO_OPCIONES) {
                    throw new Exception("\nOpción incorrecta. ");
                } else {
                    ejecutarOpcionMenu(opcion);
                    opcion = 0;
                }

            } catch (InputMismatchException ex) {
                //Excepción lanzada si el tipo de valor introducido no es numérico.
                System.out.print("Opción incorrecta. ");
                System.out.print("Elige una opción entre 1 y " + NUMERO_OPCIONES + ": ");
                opcion = 0;

            } catch (Exception ex) {
                //Excepción lanzada si el número introducido no está dentro del rango de opciones válidas.
                System.out.print(ex.getMessage());
                System.out.print("Elige una opción entre 1 y " + NUMERO_OPCIONES + ": ");
                opcion = 0;
                ex.printStackTrace();

            }

        } while (opcion == 0);
    }
    /**
     * Método que se encarga de imprimir por pantalla el menú del programa.
     * 
     */
    public static void mostrarMenu() {
        
        System.out.println("\n********************* Menú ********************");
        System.out.println("----------------------------------------------\n");
        System.out.println("(1) Abrir cuenta nueva.");
        System.out.println("(2) Ver listado de cuentas disponibles.");
        System.out.println("(3) Obtener datos de una cuenta.");
        System.out.println("(4) Realizar ingreso en cuenta.");
        System.out.println("(5) Retirar efectivo de cuenta.");
        System.out.println("(6) Consultar saldo de cuenta.");
        System.out.println("(7) Salir.");
        System.out.println("\n----------------------------------------------");
        System.out.print("Elige una opción: ");

    }
    
    /**
     * Método que se encarga de llamar al método mostrarMenu cuando se pulsa
     * cualquier tecla.
     */
    public static void switchMostrarMenu() {
        
       /*de esta manera evitamos que aparezca el menú justo después
        de realizar cualquier operación que requiera ver datos en pantalla y es
        más cómodo para la vista.*/

        System.out.println("\nPulsa cualquier tecla para mostrar el menú.");
        new Scanner(System.in).nextLine();

    }
    
    /**
     * Método encargado de ejecutar las distintas opciones del menú a partir
     * de la opción que haya introducido el usuario.
     * 
     * @param opcion opción a ejecutar.
     */
    public static void ejecutarOpcionMenu(int opcion) {
        String[] numerosCuentaUsuario = null;
        switch (opcion) {

            case 1:
                //Llamamos al método encargado de crear cuentas bancarias.
                crearCuenta();

                break;
            case 2:
                //Llamamos al método encargado de listar el total de las cuentas bancarias.
                listarCuentas();
                switchMostrarMenu();

                break;

            case 3:
                /*Llamamos al método encaragado de buscar las cuentas bancarias.
                con el método buscarCuenta, que puede devolver 1 o más cuentas
                bancarias, o puede devolver error.
                */
                try {
                    
                   numerosCuentaUsuario = buscarCuenta(); 
                   
                   /*Si se devuelve una o varias cuentas, llamamos al método
                   que se encarga de devolver los datos exactos en un string,
                   pasándole como parámetro un método que se encarga de
                   seleccionar la cuenta exacta en caso de que tengamos aún
                   varias cuentas en el array devuelto.*/
                   
                   String datos = banco.informacionCuenta(seleccionarCuentaUsuario(numerosCuentaUsuario));
                   
                   /*
                   Llamamos al método que se encarga de devolver los datos
                   de la cuenta por separado.
                   */
                   separarCadenaCuenta(datos);
                   
                }catch (Exception ex) {
                    
                    System.out.println(ex.getMessage());
                }

                switchMostrarMenu();
                
                break;

            case 4:
                /*
                 * Llamamos al método que se encarga de ingresar efectivo en
                 * una cuenta determinada.
                 */
                ingresoCuenta();
                switchMostrarMenu();
                break;

            case 5:
                /*
                 * Llamamos al método que se encarga de retirar efectivo de
                 * una cuenta determinada.
                 */
                retiroCuenta();
                switchMostrarMenu();
                break;

            case 6:
                /*
                 * Llamamos al método que se encarga de consultar el saldo actual
                 * de una cuenta determinada.
                 */
                consultarSaldo();
                switchMostrarMenu();
                break;

            case 7:
                /* Forzamos la salida del programa. */
                System.exit(0);
                break;
        }
        
        //Cuando se termina de ejecutar cualquier opción mostramos el menú de nuevo.
        mostrarMenu();
    }
    
    /**
     * Método que se encarga de crear una cuenta bancaria, en caso de que el titular
     * no exista, también se encarga de crearlo, en caso contrario se creará la
     * cuenta a partir de los datos del cliente existente.
     * 
     */
    public static void crearCuenta() {

        System.out.println("Crear cuenta para el cliente.");
        System.out.println("****************************************************************");
        // Pedimos el dni al usuario y llamamos al método que se encarga de validarlo.
        Scanner dato = new Scanner(System.in);
        String dni = pedirDni(dato);
        
        /* Llamamos al método que se encarga de pedir los datos del titular de la
        cuenta, nos devuelve un array que almacenamos en los strings correspondientes.
        Este método se encarga además de revisar si el DNI del cliente ya existe en
        las cuentas corrientes existentes y en caso de que no exista, pide los datos
        del nuevo cliente.
        */
        
        String[] datosTitular = pedirDatosTitular(dni);
        String nombre = datosTitular[0];
        String apellidos = datosTitular[1];
        
        
        System.out.print("\n¿Deseas crear otra cuenta para el cliente? S para continuar: ");
        boolean continuar = (dato.nextLine().toUpperCase().equals("S"));
        
        //llamamos al método que se encarga de crear la cuenta bancaria.
        
        if (continuar) {
            pedirDatosCuenta(nombre, apellidos, dni);
        }

    }
    
    /**
     * Método que se encarga de pedir el DNI al cliente y validarlo antes
     * de continuar con el alta de la cuenta.
     * 
     * @param dato dni del cliente introducido por el usuario en consola
     * 
     * @return devuelve un String con el dni introducido o captura una excepción
     * si el dni no es válido.
     */
    
    public static String pedirDni(Scanner dato) {
        String dni = null;
        while (!Objects.nonNull(dni)) {
            try {
                System.out.print("DNI: ");
                dni = dato.nextLine().toUpperCase();
                ValidarDatos.validarDNI(dni);

            } catch (Exception ex) {
                dni = null;
                System.out.println("DNI Incorrecto. Escribe un DNI válido.");

            }
        }
        return dni;
    }

    /**
     * Método que se encarga de pedir los datos del titular de la cuenta bancaria,
     * en caso de que exista alguna cuenta asociada a su DNI, en caso contrario, 
     * se piden los datos por consola, en ambos casos se devuelve un array con los
     * datos obtenidos.
     * 
     * @param dni del cliente que se va a analizar si existe.
     * @return array de Strings con los datos del cliente almacenados.
     */
    public static String[] pedirDatosTitular(String dni) {
        Scanner dato = new Scanner(System.in);
        String[] datosTitular = new String[3];

        datosTitular = banco.getDatosTitularCuenta(dni);

        if (Objects.nonNull(datosTitular)) {
            System.out.println("El cliente ya existe:\n");
            System.out.println("Nombre: " + datosTitular[0]);
            System.out.println("Apellidos: " + datosTitular[1]);
            System.out.println("DNI: " + datosTitular[2]);

        } else {

            System.out.print("Nombre: ");
            datosTitular[0] = dato.nextLine();
            System.out.print("Apellidos: ");
            datosTitular[1] = dato.nextLine();

        }

        return datosTitular;
    }
    
    /**
     * Método encargado de pedir los datos necesarios por consola 
     * para generar una cuenta bancaria a partir de los datos del titular ya 
     * obtenidos.
     * 
     * @param nombre nombre del titular de la cuenta
     * @param apellidos apellidos del titular de la cuenta
     * @param dni dni del titular de la cuenta
     */
    public static void pedirDatosCuenta(String nombre, String apellidos, String dni) {
        Scanner dato = new Scanner(System.in);
        //Pedimos el tipo de cuenta que vamos a generar y lo almacenamos en una variable de tipo entera.
        
        System.out.println("\ntipo de cuenta: ");
        System.out.println("(1): Cuenta de ahorro. ");
        System.out.println("(2): Cuenta corriente personal. ");
        System.out.println("(3): Cuenta corriente de empresa. ");

        int tipoCuenta = pedirTipoCuenta();
        
        String numeroCuenta = pedirNumeroCuenta();
        
        double saldoInicial = pedirSaldoInicial();
        
        //Llamamos al método encargado de generar la cuenta.
        crearNumCuenta(nombre, apellidos, dni, tipoCuenta, numeroCuenta, saldoInicial);

    }

    /**
     * Método encargado de seleccionar el tipo de cuenta que se va a crear a partir
     * de la opción que elija el usuario por consola.
     * 
     * @return variable de tipo int que indica la opción de tipo de cuenta elegida 
     * por el usuario.
     */
    public static int pedirTipoCuenta() {
        /*
        Implementamos un bucle que se repita hasta que el usuario introduzca
        una opción válida por pantalla, lanzando y capturando la excepción en cada vuelta,
        la hubiera. 
        */
        Scanner dato = new Scanner(System.in);
        int tipoCuenta = 0;
        while (tipoCuenta == 0) {

            try {

                tipoCuenta = Integer.valueOf(dato.nextLine());
                if (tipoCuenta < 1 || tipoCuenta > 3) {
                    throw new Exception();
                }

            } catch (Exception ex) {

                tipoCuenta = 0;
                System.out.print("\nOpción errónea. Por favor, introduce una opción válida: ");

            }

        }
        return tipoCuenta;
    }
    /**
     * Método encargado de pedir al usuario un número de cuenta válido por pantalla
     * Devuelve una cadena que contiene el número de cuenta.
     * @return cadena que contiene un número de cuenta.
     */
    public static String pedirNumeroCuenta() {
        Scanner dato = new Scanner(System.in);
        String numeroCuenta = null;
        while(Objects.isNull(numeroCuenta)){
            
            try {
                System.out.print("\nInserta un número de cuenta: ");
                numeroCuenta = dato.nextLine().toUpperCase();
                //Llamamos al método encargado de validar el formato del número de cuenta.
                if (!ValidarDatos.NumeroCuentaEsValido(numeroCuenta)) throw new Exception ("Formato de número de cuenta no válido.\nInserta un número de cuenta correcto: ");
                //Lanzamos excepción si el número de cuenta ya existe.
                if (banco.existeCuentaBancaria(numeroCuenta)) throw new Exception ("El número de cuenta ya existe. Elige otro.");
                
                
            } catch (Exception ex) {
                numeroCuenta = null;
                System.out.println(ex.getMessage());
                
            }
            
        }
        return numeroCuenta;
    }
    
    /**
     * Método encargado de pedir un saldo inicial para crear una cuenta bancaria,
     * genera un bucle del que no se sale hasta que se introduzca una cantidad mayort
     * que cero.
     * @return tipo double que contiene el valor del saldo inicial de la cuenta.
     */
    public static double pedirSaldoInicial() {
        /* Generamos un bucle que fuerce su repetición hasta que el dato
        introducido sea numérico y mayor que cero. En cada vuelta de bucle
        lanzamos y capturamos la excepción si es necesario.
        */
        Scanner dato = new Scanner(System.in);
        double saldoInicial = -1;
        while (saldoInicial == -1) {
            System.out.print("\nSaldo inicial: ");
            try {
                saldoInicial = Double.valueOf(dato.nextLine());
                if (saldoInicial < 0) {
                    throw new Exception();
                }
            } catch (Exception ex) {

                saldoInicial = -1;
                System.out.println("Debes introducir una cantidad válida.");

            }

        }
        return saldoInicial;
    }
    
    /**
     * Método encargado de llamar al método encargado de crear cuentas bancarias
     * a partir de todos los datos que recibe por parámetro
     * 
     * @param nombre nombre del titular de la cuenta.
     * @param apellidos apellidos del titular de la cuenta.
     * @param dni DNI del titular de la cuenta.
     * @param tipoCuenta tipo de cuenta bancaria.
     * @param numeroCuenta número de cuenta asociada.
     * @param saldoInicial saldo inicial de la cuenta.
     */

    public static void crearNumCuenta(String nombre, String apellidos, String dni, int tipoCuenta, String numeroCuenta, double saldoInicial) {

        System.out.println(banco.crearCuentaBancaria(nombre, apellidos, dni, tipoCuenta, numeroCuenta, saldoInicial)
                ? "Cuenta corriente creada con éxito" : "La cuenta corriente no ha sido creada.");

    }
    
    /**
     * Método encargado de listar el total de las cuentas bancarias guardadas 
     * en el array donde se almacenan.
     */
    public static void listarCuentas() {
        
        /*Guardamos en un array de strings la totalidad de los datos de las cuentas
        devueltos por el método listadoCuentas o capturamos la excepción si no hay
        cuentas creadas.*/
        String[] cuentas;
        try {
            cuentas = banco.listadoCuentas();
      
            for (String cuenta : cuentas) {
                
                /*Para cada cuenta, llamamos al método que se encarga de separar
                los distintos datos e imprimirlos por pantalla.*/
                separarCadenaCuenta(cuenta);
            }

         } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

    }
    
    /**
     * Método que se encarga de separar los datos de una cuenta bancaria contenidos
     * en una variable de tipo String e imprimirlos por pantalla.
     * @param cuenta cuenta bancaria cuyos datos se van a separar e imprimir.
     */
    public static void separarCadenaCuenta(String cuenta) {
        String[] datosSeparados = cuenta.split("\\|");
        System.out.println("\n*************************************************************************");
        for (String d : datosSeparados) {
            System.out.println(d.trim());
        }

    }
    
    /**
     * Método encargado de buscar una cuenta bancaria a partir de los datos
     * proporcionados por el usuario a través de la consola, si el usuario busca
     * un número de cuenta a partir del DNI del cliente, se evalúa si el cliente
     * tiene cuentas asociadas y cuántas, devolviéndolas todas en un array, si
     * la búsqueda se hace por IBAN se busca en el array de cuentas bancarias
     * el número de cuenta coincidiente.
     * 
     * @return array que contiene la o las cuentas que coinciden con la búsqueda
     * @throws Exception excepción lanzada si se selecciona una opción incorrecta,
     * o si no se encuentra ninguna cuenta bancaria.
     */
    public static String[] buscarCuenta() throws Exception {
        
        /*Preguntamos al usuario si quiere buscar el número de cuenta a partir
        del número de cuenta, o a partir del dni del usuario.*/
        
        Scanner dato = new Scanner(System.in);
        System.out.println("Buscar cuenta bancaria:");
        System.out.println("(1) Por DNI del titular");
        System.out.println("(2) Por IBAN");
        System.out.print("\nElige una opción: ");

        String[] numerosCuenta = null;
        
        /*Lanzamos una excepción si la opción introducida no es numérica y la
        capturamos a la vez que le damos un valor numérico que haga lanzar otra
        excepción más adelante como valor incorrecto.*/
   
        int buscarCuenta;
        try {
            buscarCuenta = Integer.valueOf(dato.nextLine());
            
            } catch (NumberFormatException ex) {
                
                buscarCuenta = -1;
            }
      
        
        switch (buscarCuenta) {
            case 1:
                
                
                System.out.print("\nIntroduce el DNI del cliente: ");
                String dni = dato.nextLine().toUpperCase();
                
                /*En caso que el usuario selecicone buscar por DNI, llamamos
                a un método que se encarga de devolver la cantidad de cuentas
                bancarias que tiene asociadas el cliente.*/
                
                int cantidadCuentas = banco.cantidadCuentasUsuario(dni);
                
                /*Si no encuentra cuentas asociadas a ese dni se lanza una excepción*/
                if (cantidadCuentas == 0) {
                    throw new Exception ("El usuario no tiene cuentas asociadas.");
                /*Si encuentra cuentas asociadas, guardamos en un array el listado
                  completo de números de cuenta pertenecientes al usuario llamando
                  al método correspondiente.*/
                } else if (cantidadCuentas > 0) {
                    numerosCuenta = banco.listadoNumerosCuentaUsuario(dni);
                }

                break;

            case 2:
                /*En caso que el usuario elija buscar por número de cuenta, creamos
                un array de una única posición donde guardaremos el número de cuenta
                introducido por el usuario. */
                numerosCuenta = new String[1];
                System.out.print("\nIntroduce el número de cuenta del cliente: ");
                numerosCuenta[0] = dato.nextLine();

                break;

            default:
                throw new Exception ("Opción incorrecta.");

        }
        /*Si el array de números de cuenta tiene valores, se devuelve y si no
        lanzamos una excepción.*/
        if (Objects.nonNull(numerosCuenta)) return numerosCuenta;
        else throw new Exception ("El número de cuenta no existe.");


    }
    
    /**
     * Método encargado de devolver una cadena que contiene una cuenta de usuario 
     * determinada a partir de un array de cuentas pertenecientes a un único usuario
     * pasadas por parámetro.
     * 
     * @param numerosCuenta array de números de cuenta pertenecientes a un usuario.
     * @return 
     */

    public static String seleccionarCuentaUsuario(String[] numerosCuenta) {
        /*Si el array de números de cuenta del usuario es de tamaño uno, creamos
        una variable de tipo String y le asignamos el valor de la única fila
        del array.*/
        String cuenta = null;
        if (numerosCuenta.length == 1) {

            cuenta = numerosCuenta[0];

        } else {
            /*Si el array de cuentas bancarias tiene varias filas de números de
            cuenta, pedimos al usuario elegir una de las cuentas bancarias por consola
            imprimiendo y ofreciendo tantas opciones como cuentas haya en el array.*/
            System.out.println("El usuario tiene varias cuentas asociadas.");
            for (int i = 0; i < numerosCuenta.length; i++) {
                System.out.println("(" + (i + 1) + ") " + numerosCuenta[i]);
            }

            System.out.print("\nElige una: ");
            int opcionNCuenta = 0;
            
            /*Generamos un bucle que fuerce su repetición si no se elige un valor
            adecuado.*/
            while (opcionNCuenta < 1 || opcionNCuenta > numerosCuenta.length) {
                try {
                    opcionNCuenta = Integer.valueOf(new Scanner(System.in).nextLine());

                    cuenta = numerosCuenta[opcionNCuenta - 1];

                } catch (Exception ex) {
                    opcionNCuenta = 0;
                    System.out.print("\nOpción incorrecta. Inténtalo de nuevo: ");

                } //fin try
            } //fin while

        } // fin if-else
        //Devolvemos un String con la cuenta seleccionada.
        return cuenta;
    }
    
    /**
     * Método que recoge el valor numérico a ingresar en una determinada cuenta
     * y llama al método encargado de hacer el ingreso en la misma.
     */

    public static void ingresoCuenta() {
        String[] numerosCuentaUsuario;
        System.out.println("\nIngreso efectivo en cuenta.");
        System.out.println("****************************************************************");
        try {
          
            /*Llamamos al método encargado de buscar cuentas para seleccionar
            las cuentas del usuario y seguidamente al método encargado de elegir
            la cuenta exacta en la que se realizará el ingreso.*/
          numerosCuentaUsuario = buscarCuenta();
          String numeroCuenta = seleccionarCuentaUsuario(numerosCuentaUsuario);
          
          /*Si existe la cuenta pedimos la cantidad a ingresar y lanzamos y capturamos
          una excepción en el caso que el dato introducido sea incorrecto.*/
            if (banco.existeCuentaBancaria(numeroCuenta)){
                System.out.print("Cantidad a ingresar: ");  

                double cantidad = new Scanner(System.in).nextDouble();
                banco.ingresoCuenta(numeroCuenta, cantidad);
                System.out.println("\nIngreso realizado correctamente.");

            }
            
        } catch (InputMismatchException ex) {

            System.out.println("La cantidad a ingresar es errónea.");
            
        } catch (Exception ex) {

            System.out.println(ex.getMessage());
        } 
 
    }
    
    /**
     * Método que recoge el valor numérico a retirar de una determinada cuenta
     * y llama al método encargado de hacer el retiro de efectivo en la misma.
     */

    public static void retiroCuenta() {
        /*Llamamos al método encargado de buscar cuentas para seleccionar
        las cuentas del usuario y seguidamente al método encargado de elegir
        la cuenta exacta en la que se realizará la retirada.*/
        
        String[] numerosCuentaUsuario;
        System.out.println("\nRetirada de efectivo de cuenta.");
        System.out.println("****************************************************************");
        try {
          /*Si existe la cuenta pedimos la cantidad a retirar y lanzamos y capturamos
          una excepción en el caso que el dato introducido sea incorrecto.*/
          numerosCuentaUsuario = buscarCuenta();
          String numeroCuenta = seleccionarCuentaUsuario(numerosCuentaUsuario);
 
            if (banco.existeCuentaBancaria(numeroCuenta)){
                System.out.print("Cantidad a retirar: ");  

                double cantidad = new Scanner(System.in).nextDouble();
                banco.retiroCuenta(numeroCuenta, cantidad);
                System.out.println("\nRetirada de efectivo realizada correctamente.");

            }
            
        } catch (InputMismatchException ex) {

            System.out.println("La cantidad a retirar es errónea.");
            
        } catch (Exception ex) {

            System.out.println(ex.getMessage());
        } 
    }
    
    /**
     * Método que consulta el saldo disponible en una cuenta determinada.
     * 
     */

    public static void consultarSaldo() {
        String[] numerosCuentaUsuario;
        System.out.println("\nConsultar saldo en cuenta.");
        System.out.println("****************************************************************");
       
        /*Llamamos al método encargado de buscar cuentas para seleccionar
        las cuentas del usuario y seguidamente al método encargado de elegir
        la cuenta exacta de la que vamos a obtener el saldo. Si la cuenta no existe
        capturamos la excepción del método y lo mostramos.*/
        try {
           numerosCuentaUsuario = buscarCuenta();
           String numeroCuenta = seleccionarCuentaUsuario(numerosCuentaUsuario);
           System.out.println("El saldo actual de la cuenta seleccionada es: " + banco.getSaldoCuentaBancaria(numeroCuenta));
           
       }catch (Exception ex) {

            System.out.println(ex.getMessage());

        }
  
    }

}
