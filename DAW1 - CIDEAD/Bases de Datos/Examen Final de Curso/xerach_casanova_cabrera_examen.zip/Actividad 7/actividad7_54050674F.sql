CREATE OR REPLACE TYPE alumno AS OBJECT(
    expediente INTEGER,
    nombre VARCHAR2(100),
    apellidos VARCHAR2(99),
    fechaNac DATE,
    repetidor VARCHAR(2),
    email VARCHAR2(99),
    
    CONSTRUCTOR FUNCTION alumno(expediente INTEGER, 
                                nombre VARCHAR2, 
                                ap1 VARCHAR2,
                                ap2 VARCHAR2,
                                fechaNac DATE,
                                repetidor VARCHAR2,
                                email VARCHAR2)
                                RETURN SELF AS RESULT
);
/

CREATE OR REPLACE TYPE BODY alumno AS 
    CONSTRUCTOR FUNCTION alumno(expediente INTEGER, 
                                nombre VARCHAR2, 
                                ap1 VARCHAR2,
                                ap2 VARCHAR2,
                                fechaNac DATE,
                                repetidor VARCHAR2,
                                email VARCHAR2)
                                RETURN SELF AS RESULT
    IS
        BEGIN
            
            SELF.expediente := expediente;
            SELF.nombre := nombre;
            SELF.apellidos := ap1 || ' ' || ap2;
            SELF.fechaNac := fechaNac;
            SELF.repetidor := repetidor;
            SELF.email := email;
 
            RETURN;
        END;
END;
/