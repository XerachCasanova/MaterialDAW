CREATE OR REPLACE PROCEDURE AlumnadoGrupo(
                            id_grupoOrigen grupo.id%TYPE, 
                            id_grupoDestino grupo.id%TYPE)
AS
    
    vGrupoOrigen grupo.id%TYPE; 
    vGrupoDestino grupo.id%TYPE; 
    
BEGIN
    
    
    SELECT id into vGrupoOrigen FROM grupo WHERE id = id_grupoOrigen;
    SELECT id into vGrupoDestino FROM grupo WHERE id = id_grupoOrigen;

    UPDATE alumnado SET grupo = vGrupoDestino WHERE grupo = vGrupoOrigen;
    DBMS_OUTPUT.PUT_LINE('Se han trasladado todos los alumnos del grupo' || vGrupoOrigen || ' al grupo ' || vGrupoDestino);

   
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Grupos no v�lidos');
END;
/

DECLARE

    p_id_grupoOrigen grupo.id%TYPE := &grupoOrigen;
    p_id_grupoDestino grupo.id%TYPE := &grupoDestino;

BEGIN
    

    AlumnadoGrupo(p_id_grupoOrigen, p_id_grupoDestino);
    
END;
/


CREATE OR REPLACE TRIGGER integridad_grupo
BEFORE INSERT OR UPDATE ON grupo
FOR EACH ROW

BEGIN
    
    IF (:NEW.maxestudiantes < 1) THEN
        RAISE_APPLICATION_ERROR(-20205, 'No pueden haber cursos con menos de un estudiante m�ximo permitido.');
    END IF;
    IF :NEW.turno < 1 OR :NEW.turno  > 3 OR :NEW.turno IS NULL THEN
        RAISE_APPLICATION_ERROR(-20206, 'El turno debe tener valor 1, 2 o 3');
    END IF;

END;
/

