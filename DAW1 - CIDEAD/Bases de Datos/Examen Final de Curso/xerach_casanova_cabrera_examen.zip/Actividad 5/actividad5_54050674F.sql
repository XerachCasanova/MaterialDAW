INSERT INTO TURNO VALUES
(1, 'MA�ANA', '8:00');

INSERT INTO TURNO VALUES
(2, 'TARDE', '14:00');

INSERT INTO TURNO VALUES
(3, 'NOCHE', '19:00');

INSERT INTO GRUPO VALUES
('DAWA', 'Desarrollo de Aplicaciones Web', 1, 22);

INSERT INTO GRUPO VALUES
('DAWB', 'Desarrollo de Aplicaciones Multiplataforma', 2, 15);

INSERT INTO GRUPO VALUES
('ASIR', 'Administraci�n de Sistemas Inform�ticos', 3, 25);

INSERT INTO ALUMNADO VALUES
(1, 'XERACH', 'CASANOVA', 'CABRERA', '21/10/84', 'si', 'xerach@xerach.com', 'DAWA');

INSERT INTO ALUMNADO VALUES
(2, 'JUAN', 'P�REZ', 'RODR�GUEZ', '20/11/88', 'no', 'juan@juan.com', 'DAWA');

INSERT INTO ALUMNADO (expedienteA, nombreA, ap1, fechaNacA, repetidor, email, grupo) VALUES
(3, 'MARCOS', 'GONZ�LEZ', '03/02/96', 'no', 'marcos@marcos.com', 'DAWA');

UPDATE GRUPO SET
MAXESTUDIANTES = (SELECT COUNT(EXPEDIENTEA) FROM ALUMNADO )
WHERE ID = 'DAWB';

INSERT INTO ALUMNADO (expedienteA, nombreA, ap1, fechaNacA, repetidor, email, grupo)
SELECT expedienteA, nombreA, ap1, fechaNacA, repetidor, email, 'DAWA' FROM ALUMNADORECIENTE;