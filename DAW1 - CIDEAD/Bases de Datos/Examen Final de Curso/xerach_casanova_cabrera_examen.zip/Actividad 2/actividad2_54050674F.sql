CREATE TABLE CONCESIONARIO (
    codigoConcesionario INTEGER NOT NULL,
    denominacion VARCHAR2(50) NOT NULL,
    telefono VARCHAR2(15),
    codigoPostal VARCHAR2(5) NOT NULL
);

CREATE TABLE VEHICULO (
    VIN CHAR(17) NOT NULL,
    matricula VARCHAR2(10) NOT NULL,
    marca VARCHAR2(30) NOT NULL,
    modelo VARCHAR2(30) NOT NULL,
    peso NUMBER(7,2) NOT NULL,
    concesionario INTEGER NOT NULL
);


ALTER TABLE CONCESIONARIO ADD CONSTRAINT pk_concec
PRIMARY KEY (codigoConcesionario);

ALTER TABLE VEHICULO ADD CONSTRAINT pk_vehic
PRIMARY KEY (VIN);

ALTER TABLE VEHICULO ADD CONSTRAINT fk_concec
FOREIGN KEY (concesionario) REFERENCES CONCESIONARIO(codigoConcesionario);

ALTER TABLE VEHICULO ADD CONSTRAINT uk_matric
UNIQUE (Matricula);

ALTER TABLE VEHICULO ADD CONSTRAINT ck_peso
CHECK (peso > 0);

ALTER TABLE VEHICULO ADD 
ITV CHAR CONSTRAINT ck_ITV CHECK (ITV IN ('S', 'N'));

COMMENT ON TABLE CONCESIONARIO IS 'Almacenaje de distintos concesionarios';
COMMENT ON COLUMN CONCESIONARIO.codigoConcesionario IS 'Primary key de la tabla concesionario';
COMMENT ON COLUMN CONCESIONARIO.denominacion IS 'Nombre del concesionario';
COMMENT ON COLUMN CONCESIONARIO.telefono IS 'Tel�fono del concesionario';
COMMENT ON COLUMN CONCESIONARIO.codigoPostal IS 'C�digo postal del concesionario';

COMMENT ON TABLE VEHICULO IS 'Almacenaje de veh�culos y el concesionario al que pertenecen';
COMMENT ON COLUMN VEHICULO.VIN IS 'N�mero de bastidor del veh�culo';
COMMENT ON COLUMN VEHICULO.matricula IS 'Matr�cula del veh�culo';
COMMENT ON COLUMN VEHICULO.marca IS 'Marca del veh�culo';
COMMENT ON COLUMN VEHICULO.modelo IS 'Modelo del veh�culo';
COMMENT ON COLUMN VEHICULO.peso IS 'Peso del veh�culo';
COMMENT ON COLUMN VEHICULO.concesionario IS 'Foreign key hacia concesionario';

ALTER TABLE CONCESIONARIO DROP COLUMN telefono;

