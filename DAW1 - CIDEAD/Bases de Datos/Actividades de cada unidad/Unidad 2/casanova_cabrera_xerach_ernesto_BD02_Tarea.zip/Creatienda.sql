-- EJERCICIO 1:
-- Vamos a crear las tablas para una tienda virtual que distribuye productos agrupados en familias en varias tiendas.
-- Realiza un script llamado Creatienda.sql que implemente los ejercicios descritos a continuaci�n.
-- Precede cada una de las sentencias SQL de los ejercicios con un comentario que incluya el enunciado del ejercicio 
-- correspondiente. Recuerda que los comentarios van precedidos del s�mbolo -- al inicio de la l�nea.
-- Con las sentencias DDL de SQL crea la tablas especificadas a continuaci�n aplicando las restricciones (constraints) pedidas. 
-- Se debe cumplir la integridad referencial.

CREATE TABLE FAMILIA ( 
Codfamilia  NUMBER(3) CONSTRAINT Familia_PK PRIMARY KEY,
Denofamilia VARCHAR(50) CONSTRAINT Familia_UK UNIQUE NOT NULL);

COMMENT ON TABLE FAMILIA IS 'Contiene las familias a las que pertenecen los productos, como por ejemplo ordenadores, 
impresoras,etc.';
COMMENT ON COLUMN FAMILIA.Codfamilia IS 'C�digo que distingue una familia de otra';
COMMENT ON COLUMN FAMILIA.Denofamilia IS 'Denominaci�n de la familia';

-- Creo la tabla FAMILIA con las siguientes columnas:
-- el campo Codfamilia es de tipo n�merico de 3 d�gitos y clave primaria.
-- el campo Denofamilia es alfanum�rico de 50 caracteres, no pueden haber dos filas iguales y debe tener contenido.
-- A�ado comentarios a las columnas para describirlas.

CREATE TABLE PRODUCTO (
Codproducto NUMBER(5) CONSTRAINT Producto_PK PRIMARY KEY,
Denoproducto VARCHAR(20) NOT NULL,
Descripcion VARCHAR(100),
PrecioBase NUMBER(8,2) CONSTRAINT PreBa_CK CHECK (PrecioBase > 0) NOT NULL,
PorcReposicion NUMBER(3) CONSTRAINT PorcRepo_CK CHECK (PorcReposicion > 0),
UnidadesMinimas NUMBER(4) CONSTRAINT UnidMin_CK CHECK (UnidadesMinimas > 0) NOT NULL,
Codfamilia NUMBER(3) CONSTRAINT Prod_Fam_FK REFERENCES FAMILIA (Codfamilia) NOT NULL);


COMMENT ON TABLE PRODUCTO IS 'Contiene informaci�n general sobre los productos que distribuye la empresa a las tiendas.';
COMMENT ON COLUMN PRODUCTO.Codproducto IS 'C�digo que distingue un producto de otro';
COMMENT ON COLUMN PRODUCTO.Denoproducto IS 'Denominaci�n del producto';
COMMENT ON COLUMN PRODUCTO.Descripcion IS 'Descripci�n del producto';
COMMENT ON COLUMN PRODUCTO.PrecioBase IS 'Precio base del producto';
COMMENT ON COLUMN PRODUCTO.PorcReposicion IS 'Porcentaje de reposici�n aplicado a ese producto. Se utilizar� para aplicar 
a las unidades m�nimas y obtener el n�mero total de unidades a reponer cuando el stock est� bajo m�nimo';
COMMENT ON COLUMN PRODUCTO.UnidadesMinimas IS 'Unidades m�nimas recomendables en almacen';
COMMENT ON COLUMN PRODUCTO.Codfamilia IS 'C�digo de la familia a la que pertenece el producto';

-- Creo la tabla PRODUCTO con las siguientes columnas:
-- Codproducto es n�merico de 5 d�gito y clave primaria
-- Denoproducto es alfanum�rico de 100 caracteres y no tiene restricciones.
-- PrecioBase es num�rico de 8 d�gitos y dos de ellos decimales, debe ser mayor que 0 y debe tener contenido.
-- PorcReposicion es num�rico de 3 d�gitos y mayor que cero
-- UnidadesMinimas es num�rico de 4 d�gitos, mayor que cero y debe tener contenido.
-- Codfamilia es num�rico de 3 d�gitos es clave ajena de Codfamilia en la tabla familia y debe tener contenido

CREATE TABLE TIENDA (
Codtienda NUMBER(3) CONSTRAINT Tienda_PK PRIMARY KEY,
Denotienda VARCHAR(20) NOT NULL,
Telefono VARCHAR(11),
CodigoPostal VARCHAR(5) NOT NULL,
Provincia VARCHAR (5) NOT NULL);

COMMENT ON TABLE TIENDA IS 'Contiene informaci�n b�sica sobre las tiendas que distribuyen los productos.';
COMMENT ON COLUMN TIENDA.Codtienda IS 'C�digo que distingue una tienda de otra.';
COMMENT ON COLUMN TIENDA.Denotienda IS 'Denominaci�n o nombre de la tienda.';
COMMENT ON COLUMN TIENDA.Telefono IS 'Tel�fono de la tienda.';
COMMENT ON COLUMN TIENDA.CodigoPostal IS 'Codigo Postal donde se ubica la tienda.';
COMMENT ON COLUMN TIENDA.Provincia IS 'Provincia donde se ubica la tienda.';

-- Creo la tabla TIENDA con las siguientes columnas:
-- Codtienda es num�rico de 3 d�gitos y es clave primaria.
-- Denotienda es alfanum�rico de 20 caracteres y debe tener contenido.
-- Telefono es alfanum�rico de 11 caracateres y no tiene restricciones.
-- CodigoPostal es alfanum�rico de 5 caracteres y debe tener contenido.
-- Provincia es alfanum�rico y debe tener contenido.

CREATE TABLE STOCK (
Codtienda NUMBER(3) CONSTRAINT Sto_Tie_FK REFERENCES TIENDA (Codtienda) NOT NULL,
Codproducto NUMBER(5) CONSTRAINT Sto_Prod_FK REFERENCES PRODUCTO (Codproducto) NOT NULL,
Unidades NUMBER(6) CONSTRAINT Unid_CK CHECK (Unidades >= 0) NOT NULL,
CONSTRAINT Stock_PK PRIMARY KEY (Codtienda, Codproducto));

COMMENT ON TABLE STOCK IS 'Contiene para cada tienda el n�mero de unidades disponibles de cada producto. La clave primaria 
est� formada por la concatenaci�n de los campos Codtienda y Codproducto.';
COMMENT ON COLUMN STOCK.Codtienda IS 'C�digo de la tienda.';
COMMENT ON COLUMN STOCK.CodProducto IS 'Codigo del producto.';
COMMENT ON COLUMN STOCK.Unidades IS 'Unidades de ese producto en esa tienda';

-- Creo la tabla STOCK con las siguientes columnas:
-- Codtienda es num�rico de 3 d�gitos y es clave ajena de Codtienda de la tabla TIENDA, debe tener contenido.
-- Codproducto es num�rico de 5 d�gitos y es clave ajena de Codproducto de la tabla PRODUCTO, debe tener contenido.
-- Unidades debe ser mayor o igual a cero y debe tener contenido.
-- Codtienda y Codproducto son clave primaria de la tabla STOCK.

